<?php
/**
 * Plugin Name: WP Fort
 * Plugin URI: https://brandanabia.com/wp-fort
 * Description: Ultimate WordPress security fortress with custom login protection, IP restrictions, security logging, and Cloudflare integration.
 * Version: 1.0.0
 * Author: Brand Anabia
 * Author URI: https://brandanabia.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: wp-fort
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * 
 * @package WP_Fort
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('WP_FORT_VERSION', '1.0.0');
define('WP_FORT_PLUGIN_URL', plugin_dir_url(__FILE__));
define('WP_FORT_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('WP_FORT_PLUGIN_BASENAME', plugin_basename(__FILE__));
define('WP_FORT_PLUGIN_FILE', __FILE__);

// Autoloader function
spl_autoload_register('wp_fort_autoloader');

function wp_fort_autoloader($class_name) {
    if (false !== strpos($class_name, 'WP_Fort_')) {
        $classes_dir = realpath(plugin_dir_path(__FILE__)) . DIRECTORY_SEPARATOR . 'includes' . DIRECTORY_SEPARATOR;
        $class_file = str_replace('_', DIRECTORY_SEPARATOR, $class_name) . '.php';
        require_once $classes_dir . $class_file;
    }
}

// Plugin initialization
class WP_Fort_Plugin {
    
    private static $instance = null;
    private $core;
    private $login_protection;
    private $ip_manager;
    private $security_logs;
    private $firewall;
    private $cloudflare;
    private $admin;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->includes();
        $this->init_components();
        $this->register_hooks();
    }
    
    private function includes() {
        require_once WP_FORT_PLUGIN_PATH . 'includes/class-wp-fort-core.php';
        require_once WP_FORT_PLUGIN_PATH . 'includes/class-wp-fort-login-protection.php';
        require_once WP_FORT_PLUGIN_PATH . 'includes/class-wp-fort-ip-manager.php';
        require_once WP_FORT_PLUGIN_PATH . 'includes/class-wp-fort-security-logs.php';
        require_once WP_FORT_PLUGIN_PATH . 'includes/class-wp-fort-firewall.php';
        require_once WP_FORT_PLUGIN_PATH . 'includes/class-wp-fort-cloudflare.php';
        require_once WP_FORT_PLUGIN_PATH . 'includes/class-wp-fort-utilities.php';
        
        if (is_admin()) {
            require_once WP_FORT_PLUGIN_PATH . 'admin/class-wp-fort-admin.php';
        }
    }
    
    private function init_components() {
        $this->core = new WP_Fort_Core();
        $this->login_protection = new WP_Fort_Login_Protection();
        $this->ip_manager = new WP_Fort_IP_Manager();
        $this->security_logs = new WP_Fort_Security_Logs();
        $this->firewall = new WP_Fort_Firewall();
        $this->cloudflare = new WP_Fort_Cloudflare();
        
        if (is_admin()) {
            $this->admin = new WP_Fort_Admin();
        }
    }
    
    private function register_hooks() {
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        add_action('plugins_loaded', array($this, 'load_textdomain'));
    }
    
    public function activate() {
        // Initialize default options
        WP_Fort_Core::activate();
    }
    
    public function deactivate() {
        // Cleanup temporary data
        WP_Fort_Core::deactivate();
    }
    
    public function load_textdomain() {
        load_plugin_textdomain(
            'wp-fort',
            false,
            dirname(plugin_basename(__FILE__)) . '/languages'
        );
    }
    
    // Public access to components
    public function login_protection() {
        return $this->login_protection;
    }
    
    public function ip_manager() {
        return $this->ip_manager;
    }
    
    public function security_logs() {
        return $this->security_logs;
    }
    
    public function firewall() {
        return $this->firewall;
    }
    
    public function cloudflare() {
        return $this->cloudflare;
    }
}

// Initialize the plugin
function wp_fort_init() {
    return WP_Fort_Plugin::get_instance();
}

// Start the plugin
add_action('plugins_loaded', 'wp_fort_init');

// Global helper functions
if (!function_exists('wp_fort')) {
    function wp_fort() {
        return WP_Fort_Plugin::get_instance();
    }
}
?>