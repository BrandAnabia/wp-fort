=== WP Fort ===
Contributors: brandanabia
Donate link: https://brandanabia.com
Tags: security, login protection, firewall, ip restriction, cloudflare, security logs, brute force protection
Requires at least: 5.8
Tested up to: 6.4
Stable tag: 1.0.0
Requires PHP: 7.4
License: GPL v2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Ultimate WordPress security fortress with custom login protection, IP restrictions, security logging, and Cloudflare integration.

== Description ==

WP Fort is a comprehensive security solution that transforms your WordPress website into an impenetrable fortress. Developed by Brand Anabia, this plugin provides enterprise-level security features in an easy-to-use package.

= Key Features =

* **Custom Login URL Protection** - Hide wp-login.php and use your own secret login URL
* **IP Address Restrictions** - Allow only specific IP addresses to access admin area
* **Advanced Security Logging** - Detailed logs of all login attempts with location data
* **Smart Firewall** - Block suspicious requests and malicious traffic patterns
* **Cloudflare Integration** - Enhanced security with Cloudflare firewall rules
* **Brute Force Protection** - Automatic blocking after multiple failed attempts
* **Real-time Monitoring** - Live security dashboard with threat alerts
* **Geo-location Tracking** - See where login attempts are coming from worldwide

= Why WP Fort? =

* **Complete Security Suite** - All security features in one plugin
* **Zero Performance Impact** - Optimized code that doesn't slow down your site
* **Easy Configuration** - User-friendly dashboard with one-click setups
* **Regular Updates** - Continuous security updates and feature enhancements
* **Professional Support** - Backed by Brand Anabia development team

== Installation ==

1. Upload `wp-fort` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to WP Fort settings page to configure your security settings
4. Set up your custom login URL and allowed IP addresses
5. Enable additional security features as needed

== Frequently Asked Questions ==

= What makes WP Fort different from other security plugins? =

WP Fort provides a comprehensive approach with custom login URLs, IP restrictions, and Cloudflare integration in one package. Our focus is on prevention rather than just detection.

= Will this plugin slow down my website? =

No! WP Fort is optimized for performance and uses efficient coding practices to ensure zero impact on your site speed.

= Can I use WP Fort with other security plugins? =

While WP Fort is designed as a complete security solution, it can work alongside other plugins. We recommend testing compatibility.

== Changelog ==

= 1.0.0 =
* Initial release
* Custom login URL protection
* IP address management
* Security logging system
* Basic firewall protection
* Admin dashboard interface

== Upgrade Notice ==

= 1.0.0 =
Initial release of WP Fort security plugin.

== Screenshots ==

1. Security Dashboard - Overview of security status and recent events
2. Login Protection Settings - Configure custom login URL and IP restrictions
3. Security Logs - Detailed view of all security events with filters
4. Firewall Settings - Configure blocking rules and patterns
5. Cloudflare Integration - Connect with Cloudflare for enhanced protection

== License ==

This plugin is licensed under the GPL v2 or later.