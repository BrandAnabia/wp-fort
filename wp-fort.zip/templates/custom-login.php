<?php
/**
 * WP Fort Custom Login Template
 * 
 * @package WP_Fort
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Get WP Fort instance
$wp_fort = wp_fort();
$options = $wp_fort->core->get_options();

// Set up login URL
$login_url = site_url('wp-login.php', 'login');
if ($options['login_protection_enabled'] && !empty($options['custom_login_slug'])) {
    $login_url = home_url($options['custom_login_slug']);
}

// Handle login form submission
if (isset($_POST['wp-fort-login'])) {
    $this->handle_custom_login($_POST);
}

// Add security headers
header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header('X-XSS-Protection: 1; mode=block');

?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - <?php echo get_bloginfo('name'); ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .login-container {
            background: white;
            border-radius: 12px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 400px;
            overflow: hidden;
        }

        .login-header {
            background: #2271b1;
            color: white;
            padding: 30px 20px;
            text-align: center;
        }

        .login-header h1 {
            font-size: 24px;
            font-weight: 600;
            margin-bottom: 8px;
        }

        .login-header p {
            opacity: 0.9;
            font-size: 14px;
        }

        .login-form {
            padding: 30px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #2c3338;
            font-size: 14px;
        }

        .form-group input {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid #dcdcde;
            border-radius: 6px;
            font-size: 16px;
            transition: all 0.3s ease;
        }

        .form-group input:focus {
            outline: none;
            border-color: #2271b1;
            box-shadow: 0 0 0 3px rgba(34, 113, 177, 0.1);
        }

        .login-button {
            width: 100%;
            background: #2271b1;
            color: white;
            border: none;
            padding: 14px 20px;
            border-radius: 6px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        .login-button:hover {
            background: #135e96;
        }

        .login-button:disabled {
            background: #a7aaad;
            cursor: not-allowed;
        }

        .login-links {
            margin-top: 20px;
            text-align: center;
            font-size: 14px;
        }

        .login-links a {
            color: #2271b1;
            text-decoration: none;
        }

        .login-links a:hover {
            text-decoration: underline;
        }

        .security-notice {
            background: #f0f6fc;
            border: 1px solid #2271b1;
            border-radius: 6px;
            padding: 12px 16px;
            margin-bottom: 20px;
            font-size: 13px;
            color: #2271b1;
        }

        .error-message {
            background: #fcf0f1;
            border: 1px solid #d63638;
            border-radius: 6px;
            padding: 12px 16px;
            margin-bottom: 20px;
            font-size: 13px;
            color: #d63638;
        }

        .success-message {
            background: #edfaef;
            border: 1px solid #00a32a;
            border-radius: 6px;
            padding: 12px 16px;
            margin-bottom: 20px;
            font-size: 13px;
            color: #00a32a;
        }

        .loading-spinner {
            display: inline-block;
            width: 16px;
            height: 16px;
            border: 2px solid #ffffff;
            border-top: 2px solid transparent;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin-right: 8px;
            vertical-align: middle;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        @media (max-width: 480px) {
            .login-container {
                margin: 0;
                border-radius: 0;
                min-height: 100vh;
            }
            
            body {
                padding: 0;
                background: white;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <h1>Secure Login</h1>
            <p><?php echo get_bloginfo('name'); ?></p>
        </div>

        <div class="login-form">
            <?php if (isset($_GET['loggedout']) && $_GET['loggedout'] == 'true'): ?>
                <div class="success-message">
                    You have been successfully logged out.
                </div>
            <?php endif; ?>

            <?php if (isset($_GET['login']) && $_GET['login'] == 'failed'): ?>
                <div class="error-message">
                    Invalid login credentials. Please try again.
                </div>
            <?php endif; ?>

            <?php if (isset($_GET['error']) && $_GET['error'] == 'empty_fields'): ?>
                <div class="error-message">
                    Please enter both username and password.
                </div>
            <?php endif; ?>

            <div class="security-notice">
                <strong>Security Protected:</strong> This login is secured by WP Fort.
            </div>

            <form method="post" action="<?php echo esc_url($login_url); ?>" id="wp-fort-login-form">
                <input type="hidden" name="wp-fort-login" value="1">
                
                <div class="form-group">
                    <label for="username">Username or Email</label>
                    <input type="text" id="username" name="log" required autocomplete="username">
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="pwd" required autocomplete="current-password">
                </div>

                <div class="form-group">
                    <label>
                        <input type="checkbox" name="rememberme" value="forever">
                        Remember Me
                    </label>
                </div>

                <button type="submit" class="login-button" id="login-submit">
                    <span class="button-text">Log In</span>
                </button>
            </form>

            <div class="login-links">
                <?php if (get_option('users_can_register')): ?>
                    <p><a href="<?php echo esc_url(wp_registration_url()); ?>">Register</a></p>
                <?php endif; ?>
                <p><a href="<?php echo esc_url(wp_lostpassword_url()); ?>">Lost your password?</a></p>
                <p><a href="<?php echo esc_url(home_url()); ?>">← Back to site</a></p>
            </div>
        </div>
    </div>

    <script>
        document.getElementById('wp-fort-login-form').addEventListener('submit', function(e) {
            const submitButton = document.getElementById('login-submit');
            const buttonText = submitButton.querySelector('.button-text');
            
            // Disable button and show loading
            submitButton.disabled = true;
            buttonText.innerHTML = '<span class="loading-spinner"></span> Logging in...';
            
            // Basic client-side validation
            const username = document.getElementById('username').value.trim();
            const password = document.getElementById('password').value.trim();
            
            if (!username || !password) {
                e.preventDefault();
                alert('Please enter both username and password.');
                submitButton.disabled = false;
                buttonText.textContent = 'Log In';
                return false;
            }
        });

        // Add some security enhancements
        document.addEventListener('DOMContentLoaded', function() {
            // Prevent copy-paste on password field (optional)
            const passwordField = document.getElementById('password');
            passwordField.addEventListener('copy', function(e) {
                e.preventDefault();
            });
            passwordField.addEventListener('paste', function(e) {
                e.preventDefault();
            });

            // Auto-focus username field
            document.getElementById('username').focus();

            // Add input sanitization
            const inputs = document.querySelectorAll('input[type="text"], input[type="password"]');
            inputs.forEach(input => {
                input.addEventListener('input', function(e) {
                    // Remove potentially dangerous characters
                    this.value = this.value.replace(/[<>]/g, '');
                });
            });
        });

        // Protect against brute force by adding delay
        let loginAttempts = 0;
        const maxAttempts = 5;
        
        document.getElementById('wp-fort-login-form').addEventListener('submit', function(e) {
            loginAttempts++;
            
            if (loginAttempts > maxAttempts) {
                e.preventDefault();
                alert('Too many login attempts. Please wait a few minutes before trying again.');
                return false;
            }
            
            // Add increasing delay for multiple attempts
            if (loginAttempts > 2) {
                e.preventDefault();
                setTimeout(() => {
                    this.submit();
                }, (loginAttempts - 2) * 1000);
                return false;
            }
        });
    </script>
</body>
</html>