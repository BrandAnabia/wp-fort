<?php
/**
 * WP Fort Firewall Class
 * 
 * @package WP_Fort
 * @since 1.0.0
 */

class WP_Fort_Firewall {
    
    private $core;
    private $options;
    private $blocked_ips = array();
    
    public function __construct() {
        $this->core = WP_Fort_Core::get_instance();
        $this->options = $this->core->get_options();
        
        $this->init_hooks();
        $this->load_blocked_ips();
    }
    
    private function init_hooks() {
        // Early firewall checks
        add_action('init', array($this, 'firewall_checks'), 1);
        
        // Block suspicious requests
        add_action('wp_loaded', array($this, 'check_suspicious_requests'));
        
        // REST API protection
        add_filter('rest_authentication_errors', array($this, 'rest_api_firewall'));
        
        // XML-RPC protection
        add_filter('xmlrpc_methods', array($this, 'disable_xmlrpc_methods'));
    }
    
    /**
     * Load blocked IPs from options
     */
    private function load_blocked_ips() {
        $this->blocked_ips = $this->options['blocked_ips'] ?? array();
    }
    
    /**
     * Main firewall checks
     */
    public function firewall_checks() {
        if (!$this->options['firewall_enabled']) {
            return;
        }
        
        $this->check_blocked_ips();
        $this->check_bad_bots();
        // Removed the undefined method call
    }
    
    /**
     * Check if current IP is blocked
     */
    private function check_blocked_ips() {
        $current_ip = WP_Fort_Core::get_client_ip();
        
        foreach ($this->blocked_ips as $blocked_ip) {
            if ($this->check_ip_match($current_ip, $blocked_ip)) {
                $this->handle_blocked_ip_access($current_ip, $blocked_ip);
            }
        }
        
        // Check temporary blocks
        $temp_block_key = 'wp_fort_ip_blocked_' . md5($current_ip);
        if (get_transient($temp_block_key)) {
            $this->handle_blocked_ip_access($current_ip, 'temporary_block');
        }
    }
    
    /**
     * Check for bad bots and scanners
     */
    private function check_bad_bots() {
        if (!isset($_SERVER['HTTP_USER_AGENT'])) {
            return;
        }
        
        $user_agent = $_SERVER['HTTP_USER_AGENT'];
        $bad_bots = $this->get_bad_bot_patterns();
        
        foreach ($bad_bots as $bot_pattern) {
            if (stripos($user_agent, $bot_pattern) !== false) {
                $this->handle_bad_bot_detected($user_agent, $bot_pattern);
            }
        }
    }
    
    /**
     * Check for malicious requests
     */
    public function check_suspicious_requests() {
        if (!$this->options['block_suspicious_requests']) {
            return;
        }
        
        $this->check_sql_injection();
        $this->check_xss_attempts();
        $this->check_directory_traversal();
        $this->check_file_inclusion();
        $this->check_command_injection();
    }
    
    /**
     * Check for SQL injection attempts
     */
    private function check_sql_injection() {
        $patterns = array(
            '/union\s+select/i',
            '/insert\s+into/i',
            '/drop\s+table/i',
            '/delete\s+from/i',
            '/update\s+.+set/i',
            '/or\s+1=1/i',
            '/and\s+1=1/i',
            '/exec(\s|\()+/i',
            '/eval(\s|\()+/i',
            '/benchmark\s*\(/i'
        );
        
        $this->scan_request_for_patterns($patterns, 'sql_injection');
    }
    
    /**
     * Check for XSS attempts
     */
    private function check_xss_attempts() {
        $patterns = array(
            '/<script[^>]*>/i',
            '/javascript:/i',
            '/onload\s*=/i',
            '/onerror\s*=/i',
            '/onclick\s*=/i',
            '/onmouseover\s*=/i',
            '/alert\s*\(/i',
            '/document\.cookie/i',
            '/<iframe[^>]*>/i',
            '/<object[^>]*>/i'
        );
        
        $this->scan_request_for_patterns($patterns, 'xss_attempt');
    }
    
    /**
     * Check for directory traversal
     */
    private function check_directory_traversal() {
        $patterns = array(
            '/\.\.\//',
            '/\.\.\\\/',
            '/\/etc\/passwd/',
            '/\/etc\/hosts/',
            '/\/proc\/self/',
            '/\/\.htaccess/',
            '/\/\.env/',
            '/\/wp-config\.php/'
        );
        
        $this->scan_request_for_patterns($patterns, 'directory_traversal');
    }
    
    /**
     * Check for file inclusion
     */
    private function check_file_inclusion() {
        $patterns = array(
            '/include\s*\(/i',
            '/require\s*\(/i',
            '/include_once\s*\(/i',
            '/require_once\s*\(/i',
            '/file_get_contents\s*\(/i',
            '/file_put_contents\s*\(/i',
            '/fopen\s*\(/i',
            '/readfile\s*\(/i'
        );
        
        $this->scan_request_for_patterns($patterns, 'file_inclusion');
    }
    
    /**
     * Check for command injection
     */
    private function check_command_injection() {
        $patterns = array(
            '/system\s*\(/i',
            '/exec\s*\(/i',
            '/shell_exec\s*\(/i',
            '/passthru\s*\(/i',
            '/popen\s*\(/i',
            '/proc_open\s*\(/i',
            '/`.*`/',
            '/\|\s*sh/',
            '/\|\s*bash/',
            '/\|\s*cmd/'
        );
        
        $this->scan_request_for_patterns($patterns, 'command_injection');
    }
    
    /**
     * Scan request data for malicious patterns
     */
    private function scan_request_for_patterns($patterns, $attack_type) {
        $request_data = array_merge($_GET, $_POST, $_COOKIE);
        
        foreach ($request_data as $key => $value) {
            if (is_array($value)) {
                $value = implode(' ', $value);
            }
            
            foreach ($patterns as $pattern) {
                if (preg_match($pattern, $key) || preg_match($pattern, $value)) {
                    $this->handle_malicious_request($attack_type, $key, $value, $pattern);
                }
            }
        }
        
        // Also check request URI
        $request_uri = $_SERVER['REQUEST_URI'] ?? '';
        foreach ($patterns as $pattern) {
            if (preg_match($pattern, $request_uri)) {
                $this->handle_malicious_request($attack_type, 'REQUEST_URI', $request_uri, $pattern);
            }
        }
    }
    
    /**
     * Handle malicious request detection
     */
    private function handle_malicious_request($attack_type, $key, $value, $pattern) {
        $ip = WP_Fort_Core::get_client_ip();
        $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        
        $this->core->log_security_event(
            'firewall_blocked',
            $ip,
            '',
            $user_agent,
            array(
                'attack_type' => $attack_type,
                'key' => $key,
                'value' => substr($value, 0, 100), // Limit value length
                'pattern' => $pattern,
                'request_uri' => $_SERVER['REQUEST_URI'] ?? '',
                'timestamp' => current_time('mysql')
            ),
            'high'
        );
        
        // Block IP temporarily
        $this->block_ip_temporarily($ip, 30); // 30 minutes
        
        // Show access denied
        $this->show_access_denied($attack_type);
    }
    
    /**
     * Handle blocked IP access
     */
    private function handle_blocked_ip_access($ip, $reason) {
        $this->core->log_security_event(
            'ip_blocked_by_firewall',
            $ip,
            '',
            $_SERVER['HTTP_USER_AGENT'] ?? '',
            array(
                'reason' => $reason,
                'timestamp' => current_time('mysql')
            ),
            'high'
        );
        
        $this->show_access_denied('ip_blocked');
    }
    
    /**
     * Handle bad bot detection
     */
    private function handle_bad_bot_detected($user_agent, $bot_pattern) {
        $ip = WP_Fort_Core::get_client_ip();
        
        $this->core->log_security_event(
            'bad_bot_blocked',
            $ip,
            '',
            $user_agent,
            array(
                'bot_pattern' => $bot_pattern,
                'timestamp' => current_time('mysql')
            ),
            'medium'
        );
        
        $this->show_access_denied('bad_bot');
    }
    
    /**
     * Show access denied page
     */
    private function show_access_denied($reason = '') {
        status_header(403);
        nocache_headers();
        
        $message = __('Access Denied', 'wp-fort');
        $details = __('Your request has been blocked by the security firewall.', 'wp-fort');
        
        switch ($reason) {
            case 'sql_injection':
                $details = __('SQL injection attempt detected and blocked.', 'wp-fort');
                break;
            case 'xss_attempt':
                $details = __('Cross-site scripting (XSS) attempt detected and blocked.', 'wp-fort');
                break;
            case 'directory_traversal':
                $details = __('Directory traversal attempt detected and blocked.', 'wp-fort');
                break;
            case 'file_inclusion':
                $details = __('File inclusion attempt detected and blocked.', 'wp-fort');
                break;
            case 'command_injection':
                $details = __('Command injection attempt detected and blocked.', 'wp-fort');
                break;
            case 'ip_blocked':
                $details = __('Your IP address has been blocked by the firewall.', 'wp-fort');
                break;
            case 'bad_bot':
                $details = __('Automated bot traffic detected and blocked.', 'wp-fort');
                break;
        }
        
        wp_die($details, $message, array('response' => 403));
    }
    
    /**
     * Block IP temporarily
     */
    public function block_ip_temporarily($ip, $minutes = 30) {
        $transient_key = 'wp_fort_ip_blocked_' . md5($ip);
        set_transient($transient_key, true, $minutes * MINUTE_IN_SECONDS);
        
        return true;
    }
    
    /**
     * Block IP permanently
     */
    public function block_ip_permanently($ip) {
        if (!in_array($ip, $this->blocked_ips)) {
            $this->blocked_ips[] = $ip;
            $this->save_blocked_ips();
        }
        
        return true;
    }
    
    /**
     * Unblock IP
     */
    public function unblock_ip($ip) {
        if (($key = array_search($ip, $this->blocked_ips)) !== false) {
            unset($this->blocked_ips[$key]);
            $this->blocked_ips = array_values($this->blocked_ips);
            $this->save_blocked_ips();
        }
        
        // Also remove temporary block
        $transient_key = 'wp_fort_ip_blocked_' . md5($ip);
        delete_transient($transient_key);
        
        return true;
    }
    
    /**
     * Save blocked IPs to options
     */
    private function save_blocked_ips() {
        $options = $this->core->get_options();
        $options['blocked_ips'] = $this->blocked_ips;
        $this->core->update_options($options);
    }
    
    /**
     * Get bad bot patterns
     */
    private function get_bad_bot_patterns() {
        return array(
            'nmap', 'nikto', 'sqlmap', 'wpscan', 'acunetix',
            'nessus', 'metasploit', 'havij', 'zap', 'burp',
            'dirbuster', 'gobuster', 'wfuzz', 'skipfish',
            'arachni', 'vegile', 'morfeus', 'masscan',
            'netsparker', 'appscan', 'webinspect'
        );
    }
    
    /**
     * Check IP match (supports CIDR and wildcards)
     */
    private function check_ip_match($ip, $pattern) {
        // Exact match
        if ($ip === $pattern) {
            return true;
        }
        
        // CIDR notation
        if (strpos($pattern, '/') !== false) {
            list($subnet, $bits) = explode('/', $pattern);
            return $this->check_cidr_match($ip, $subnet, $bits);
        }
        
        // Wildcard match
        if (strpos($pattern, '*') !== false) {
            $pattern = str_replace('*', '.*', preg_quote($pattern, '/'));
            return preg_match('/^' . $pattern . '$/', $ip) === 1;
        }
        
        return false;
    }
    
    /**
     * Check CIDR match
     */
    private function check_cidr_match($ip, $subnet, $bits) {
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
            $ip = ip2long($ip);
            $subnet = ip2long($subnet);
            $mask = -1 << (32 - $bits);
            return ($ip & $mask) === ($subnet & $mask);
        }
        
        return false;
    }
    
    /**
     * REST API firewall protection
     */
    public function rest_api_firewall($result) {
        if (!$this->options['firewall_enabled']) {
            return $result;
        }
        
        // Additional REST API security checks can be added here
        return $result;
    }
    
    /**
     * Disable dangerous XML-RPC methods
     */
    public function disable_xmlrpc_methods($methods) {
        if (!$this->options['firewall_enabled']) {
            return $methods;
        }
        
        // Remove potentially dangerous methods
        $dangerous_methods = array(
            'pingback.ping',
            'pingback.extensions.getPingbacks',
            'wp.getUsersBlogs',
            'system.multicall',
            'system.listMethods'
        );
        
        foreach ($dangerous_methods as $method) {
            unset($methods[$method]);
        }
        
        return $methods;
    }
    
    /**
     * Get firewall statistics
     */
    public function get_statistics() {
        global $wpdb;
        
        $stats = array(
            'total_blocks' => 0,
            'blocks_today' => 0,
            'top_attack_types' => array(),
            'blocked_ips_count' => count($this->blocked_ips)
        );
        
        // Total blocks
        $stats['total_blocks'] = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}wp_fort_security_logs 
                 WHERE event_type = %s",
                'firewall_blocked'
            )
        );
        
        // Today's blocks
        $stats['blocks_today'] = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}wp_fort_security_logs 
                 WHERE event_type = %s AND DATE(timestamp) = %s",
                'firewall_blocked',
                current_time('mysql')
            )
        );
        
        // Top attack types
        $attack_types = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT details->>'$.attack_type' as attack_type, COUNT(*) as count 
                 FROM {$wpdb->prefix}wp_fort_security_logs 
                 WHERE event_type = %s 
                 GROUP BY details->>'$.attack_type' 
                 ORDER BY count DESC 
                 LIMIT 10",
                'firewall_blocked'
            ),
            ARRAY_A
        );
        
        foreach ($attack_types as $attack) {
            if (!empty($attack['attack_type'])) {
                $stats['top_attack_types'][$attack['attack_type']] = $attack['count'];
            }
        }
        
        return $stats;
    }
}