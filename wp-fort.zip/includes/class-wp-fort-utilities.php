<?php
/**
 * WP Fort Utilities Class
 * 
 * @package WP_Fort
 * @since 1.0.0
 */

class WP_Fort_Utilities {
    
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Generate random string
     */
    public function generate_random_string($length = 32) {
        $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $string = '';
        
        for ($i = 0; $i < $length; $i++) {
            $string .= $chars[wp_rand(0, strlen($chars) - 1)];
        }
        
        return $string;
    }
    
    /**
     * Validate email address
     */
    public function validate_email($email) {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }
    
    /**
     * Validate IP address
     */
    public function validate_ip($ip) {
        return filter_var($ip, FILTER_VALIDATE_IP) !== false;
    }
    
    /**
     * Validate URL
     */
    public function validate_url($url) {
        return filter_var($url, FILTER_VALIDATE_URL) !== false;
    }
    
    /**
     * Sanitize input data
     */
    public function sanitize_input($data) {
        if (is_array($data)) {
            return array_map(array($this, 'sanitize_input'), $data);
        }
        
        return sanitize_text_field($data);
    }
    
    /**
     * Encrypt data
     */
    public function encrypt($data, $key = '') {
        if (empty($key)) {
            $key = $this->get_encryption_key();
        }
        
        $method = 'aes-256-cbc';
        $iv_length = openssl_cipher_iv_length($method);
        $iv = openssl_random_pseudo_bytes($iv_length);
        
        $encrypted = openssl_encrypt($data, $method, $key, 0, $iv);
        
        return base64_encode($iv . $encrypted);
    }
    
    /**
     * Decrypt data
     */
    public function decrypt($data, $key = '') {
        if (empty($key)) {
            $key = $this->get_encryption_key();
        }
        
        $data = base64_decode($data);
        $method = 'aes-256-cbc';
        $iv_length = openssl_cipher_iv_length($method);
        
        $iv = substr($data, 0, $iv_length);
        $encrypted = substr($data, $iv_length);
        
        return openssl_decrypt($encrypted, $method, $key, 0, $iv);
    }
    
    /**
     * Get encryption key
     */
    private function get_encryption_key() {
        $key = get_option('wp_fort_encryption_key');
        
        if (!$key) {
            $key = $this->generate_random_string(32);
            update_option('wp_fort_encryption_key', $key);
        }
        
        return $key;
    }
    
    /**
     * Hash data
     */
    public function hash_data($data) {
        return hash('sha256', $data . $this->get_encryption_key());
    }
    
    /**
     * Verify hash
     */
    public function verify_hash($data, $hash) {
        return hash_equals($this->hash_data($data), $hash);
    }
    
    /**
     * Get server information
     */
    public function get_server_info() {
        return array(
            'php_version' => phpversion(),
            'mysql_version' => $this->get_mysql_version(),
            'web_server' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown',
            'wordpress_version' => get_bloginfo('version'),
            'wp_fort_version' => WP_FORT_VERSION,
            'server_os' => php_uname('s'),
            'server_arch' => php_uname('m'),
            'max_execution_time' => ini_get('max_execution_time'),
            'memory_limit' => ini_get('memory_limit'),
            'upload_max_filesize' => ini_get('upload_max_filesize'),
            'post_max_size' => ini_get('post_max_size')
        );
    }
    
    /**
     * Get MySQL version
     */
    private function get_mysql_version() {
        global $wpdb;
        return $wpdb->db_version();
    }
    
    /**
     * Check if function exists and is enabled
     */
    public function function_enabled($function_name) {
        return function_exists($function_name) && 
               !in_array($function_name, $this->get_disabled_functions());
    }
    
    /**
     * Get disabled PHP functions
     */
    private function get_disabled_functions() {
        $disabled = ini_get('disable_functions');
        return $disabled ? explode(',', $disabled) : array();
    }
    
    /**
     * Get file permissions
     */
    public function get_file_permissions($file_path) {
        if (!file_exists($file_path)) {
            return false;
        }
        
        $perms = fileperms($file_path);
        
        return array(
            'permissions' => substr(sprintf('%o', $perms), -4),
            'readable' => is_readable($file_path),
            'writable' => is_writable($file_path),
            'executable' => is_executable($file_path)
        );
    }
    
    /**
     * Check if site uses SSL
     */
    public function is_ssl() {
        return is_ssl();
    }
    
    /**
     * Get current URL
     */
    public function get_current_url() {
        $protocol = $this->is_ssl() ? 'https://' : 'http://';
        return $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    }
    
    /**
     * Get user agent info
     */
    public function get_user_agent_info() {
        $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
        
        return array(
            'user_agent' => $ua,
            'browser' => $this->get_browser_from_ua($ua),
            'platform' => $this->get_platform_from_ua($ua),
            'is_mobile' => wp_is_mobile(),
            'is_bot' => $this->is_bot($ua)
        );
    }
    
    /**
     * Get browser from user agent
     */
    private function get_browser_from_ua($ua) {
        $browsers = array(
            'chrome' => 'Chrome',
            'firefox' => 'Firefox',
            'safari' => 'Safari',
            'opera' => 'Opera',
            'edge' => 'Edge',
            'ie' => 'Internet Explorer'
        );
        
        foreach ($browsers as $key => $browser) {
            if (stripos($ua, $key) !== false) {
                return $browser;
            }
        }
        
        return 'Unknown';
    }
    
    /**
     * Get platform from user agent
     */
    private function get_platform_from_ua($ua) {
        $platforms = array(
            'windows' => 'Windows',
            'macintosh' => 'Mac',
            'linux' => 'Linux',
            'android' => 'Android',
            'iphone' => 'iPhone',
            'ipad' => 'iPad'
        );
        
        foreach ($platforms as $key => $platform) {
            if (stripos($ua, $key) !== false) {
                return $platform;
            }
        }
        
        return 'Unknown';
    }
    
    /**
     * Check if user agent is a bot
     */
    private function is_bot($ua) {
        $bots = array(
            'bot', 'crawl', 'spider', 'slurp', 'search', 'archiver',
            'facebook', 'twitter', 'linkedin', 'google', 'bing'
        );
        
        foreach ($bots as $bot) {
            if (stripos($ua, $bot) !== false) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Format file size
     */
    public function format_size($bytes) {
        $units = array('B', 'KB', 'MB', 'GB', 'TB');
        
        $bytes = max($bytes, 0);
        $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
        $pow = min($pow, count($units) - 1);
        
        $bytes /= pow(1024, $pow);
        
        return round($bytes, 2) . ' ' . $units[$pow];
    }
    
    /**
     * Format time duration
     */
    public function format_duration($seconds) {
        $units = array(
            'day' => 86400,
            'hour' => 3600,
            'minute' => 60,
            'second' => 1
        );
        
        $parts = array();
        
        foreach ($units as $name => $divisor) {
            $div = floor($seconds / $divisor);
            
            if ($div > 0) {
                $parts[] = $div . ' ' . $name . ($div > 1 ? 's' : '');
                $seconds %= $divisor;
            }
        }
        
        return implode(', ', $parts) ?: '0 seconds';
    }
    
    /**
     * Get directory size
     */
    public function get_directory_size($path) {
        $total_size = 0;
        
        if (!is_dir($path)) {
            return 0;
        }
        
        $files = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($path, RecursiveDirectoryIterator::SKIP_DOTS)
        );
        
        foreach ($files as $file) {
            $total_size += $file->getSize();
        }
        
        return $total_size;
    }
    
    /**
     * Clean file path
     */
    public function clean_path($path) {
        $path = str_replace(array('\\', '/'), DIRECTORY_SEPARATOR, $path);
        $parts = array_filter(explode(DIRECTORY_SEPARATOR, $path), 'strlen');
        $absolutes = array();
        
        foreach ($parts as $part) {
            if ('.' == $part) continue;
            if ('..' == $part) {
                array_pop($absolutes);
            } else {
                $absolutes[] = $part;
            }
        }
        
        return implode(DIRECTORY_SEPARATOR, $absolutes);
    }
    
    /**
     * Check if string is JSON
     */
    public function is_json($string) {
        json_decode($string);
        return json_last_error() === JSON_ERROR_NONE;
    }
    
    /**
     * Safe JSON decode
     */
    public function safe_json_decode($json, $assoc = true) {
        $decoded = json_decode($json, $assoc);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            return null;
        }
        
        return $decoded;
    }
    
    /**
     * Array to XML conversion
     */
    public function array_to_xml($array, $root_element = 'root', $xml = null) {
        if ($xml === null) {
            $xml = new SimpleXMLElement('<' . $root_element . '/>');
        }
        
        foreach ($array as $key => $value) {
            if (is_array($value)) {
                $this->array_to_xml($value, $key, $xml->addChild($key));
            } else {
                $xml->addChild($key, htmlspecialchars($value));
            }
        }
        
        return $xml->asXML();
    }
    
    /**
     * Send email notification
     */
    public function send_notification($to, $subject, $message, $headers = '') {
        if (empty($headers)) {
            $headers = array(
                'Content-Type: text/html; charset=UTF-8',
                'From: WP Fort <noreply@' . $_SERVER['HTTP_HOST'] . '>'
            );
        }
        
        return wp_mail($to, $subject, $message, $headers);
    }
    
    /**
     * Log debug information
     */
    public function log_debug($message, $data = null) {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('WP Fort Debug: ' . $message);
            
            if ($data !== null) {
                error_log('WP Fort Data: ' . print_r($data, true));
            }
        }
    }
    
    /**
     * Get plugin settings as array
     */
    public function get_settings_array() {
        $core = WP_Fort_Core::get_instance();
        return $core->get_options();
    }
    
    /**
     * Backup settings to file
     */
    public function backup_settings($file_path = '') {
        $settings = $this->get_settings_array();
        $backup_data = array(
            'timestamp' => current_time('mysql'),
            'version' => WP_FORT_VERSION,
            'settings' => $settings
        );
        
        $json_data = json_encode($backup_data, JSON_PRETTY_PRINT);
        
        if (empty($file_path)) {
            $file_path = WP_CONTENT_DIR . '/wp-fort-backup-' . date('Y-m-d-H-i-s') . '.json';
        }
        
        return file_put_contents($file_path, $json_data) !== false;
    }
    
    /**
     * Restore settings from backup
     */
    public function restore_settings($file_path) {
        if (!file_exists($file_path)) {
            return new WP_Error('file_not_found', __('Backup file not found.', 'wp-fort'));
        }
        
        $backup_data = file_get_contents($file_path);
        $backup = json_decode($backup_data, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            return new WP_Error('invalid_json', __('Invalid backup file format.', 'wp-fort'));
        }
        
        if (!isset($backup['settings'])) {
            return new WP_Error('invalid_backup', __('Invalid backup data.', 'wp-fort'));
        }
        
        $core = WP_Fort_Core::get_instance();
        $core->update_options($backup['settings']);
        
        return true;
    }
}