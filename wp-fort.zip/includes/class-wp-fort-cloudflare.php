<?php
/**
 * WP Fort Cloudflare Integration Class
 * 
 * @package WP_Fort
 * @since 1.0.0
 */

class WP_Fort_Cloudflare {
    
    private $core;
    private $options;
    private $api_base = 'https://api.cloudflare.com/client/v4/';
    
    public function __construct() {
        $this->core = WP_Fort_Core::get_instance();
        $this->options = $this->core->get_options();
        
        $this->init_hooks();
    }
    
    private function init_hooks() {
        // Sync blocked IPs with Cloudflare
        add_action('wp_fort_ip_blocked', array($this, 'sync_blocked_ip_to_cloudflare'), 10, 2);
        
        // Sync security events
        add_action('wp_fort_security_event', array($this, 'sync_security_event_to_cloudflare'), 10, 2);
    }
    
    /**
     * Test Cloudflare API connection
     */
    public function test_connection() {
        if (!$this->is_configured()) {
            return new WP_Error('not_configured', __('Cloudflare API is not configured.', 'wp-fort'));
        }
        
        $response = $this->api_request('zones/' . $this->options['cloudflare_zone_id']);
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        if (isset($response['success']) && $response['success']) {
            return array(
                'success' => true,
                'zone_name' => $response['result']['name'] ?? '',
                'status' => $response['result']['status'] ?? '',
                'plan' => $response['result']['plan']['name'] ?? ''
            );
        }
        
        return new WP_Error('api_error', __('Cloudflare API returned an error.', 'wp-fort'));
    }
    
    /**
     * Sync blocked IP to Cloudflare firewall
     */
    public function sync_blocked_ip_to_cloudflare($ip, $reason = '') {
        if (!$this->is_configured() || !$this->options['cloudflare_firewall_rules'] ?? false) {
            return false;
        }
        
        // Check if IP is already blocked in Cloudflare
        $existing_rules = $this->get_firewall_rules();
        if (!is_wp_error($existing_rules)) {
            foreach ($existing_rules as $rule) {
                if (strpos($rule['configuration']['value'], $ip) !== false) {
                    return true; // Already blocked
                }
            }
        }
        
        // Create firewall rule
        $rule_data = array(
            'description' => 'WP Fort Blocked IP: ' . $ip . ' - ' . $reason,
            'mode' => 'block',
            'configuration' => array(
                'target' => 'ip',
                'value' => $ip
            ),
            'notes' => 'Blocked by WP Fort Security on ' . current_time('mysql')
        );
        
        $response = $this->api_request(
            'zones/' . $this->options['cloudflare_zone_id'] . '/firewall/access_rules/rules',
            $rule_data,
            'POST'
        );
        
        return !is_wp_error($response) && isset($response['success']) && $response['success'];
    }
    
    /**
     * Sync security event to Cloudflare
     */
    public function sync_security_event_to_cloudflare($event_type, $event_data) {
        if (!$this->is_configured() || !$this->options['cloudflare_threat_analytics'] ?? false) {
            return false;
        }
        
        // This would typically send security events to Cloudflare's analytics
        // For now, we'll just log that we would sync
        error_log('WP Fort: Would sync event to Cloudflare: ' . $event_type);
        
        return true;
    }
    
    /**
     * Get Cloudflare firewall rules
     */
    public function get_firewall_rules() {
        if (!$this->is_configured()) {
            return new WP_Error('not_configured', __('Cloudflare API is not configured.', 'wp-fort'));
        }
        
        $response = $this->api_request(
            'zones/' . $this->options['cloudflare_zone_id'] . '/firewall/access_rules/rules'
        );
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        if (isset($response['success']) && $response['success']) {
            return $response['result'] ?? array();
        }
        
        return new WP_Error('api_error', __('Failed to fetch firewall rules.', 'wp-fort'));
    }
    
    /**
     * Create Cloudflare firewall rule
     */
    public function create_firewall_rule($rule_data) {
        if (!$this->is_configured()) {
            return new WP_Error('not_configured', __('Cloudflare API is not configured.', 'wp-fort'));
        }
        
        $response = $this->api_request(
            'zones/' . $this->options['cloudflare_zone_id'] . '/firewall/access_rules/rules',
            $rule_data,
            'POST'
        );
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        if (isset($response['success']) && $response['success']) {
            return $response['result'];
        }
        
        return new WP_Error('api_error', __('Failed to create firewall rule.', 'wp-fort'));
    }
    
    /**
     * Delete Cloudflare firewall rule
     */
    public function delete_firewall_rule($rule_id) {
        if (!$this->is_configured()) {
            return new WP_Error('not_configured', __('Cloudflare API is not configured.', 'wp-fort'));
        }
        
        $response = $this->api_request(
            'zones/' . $this->options['cloudflare_zone_id'] . '/firewall/access_rules/rules/' . $rule_id,
            array(),
            'DELETE'
        );
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        if (isset($response['success']) && $response['success']) {
            return true;
        }
        
        return new WP_Error('api_error', __('Failed to delete firewall rule.', 'wp-fort'));
    }
    
    /**
     * Get Cloudflare analytics
     */
    public function get_analytics($time_range = '-7 days') {
        if (!$this->is_configured()) {
            return new WP_Error('not_configured', __('Cloudflare API is not configured.', 'wp-fort'));
        }
        
        $params = array(
            'since' => date('c', strtotime($time_range)),
            'until' => date('c'),
            'metrics' => 'threats,pageviews,requests,bandwidth'
        );
        
        $response = $this->api_request(
            'zones/' . $this->options['cloudflare_zone_id'] . '/analytics/dashboard',
            $params
        );
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        if (isset($response['success']) && $response['success']) {
            return $response['result'];
        }
        
        return new WP_Error('api_error', __('Failed to fetch analytics.', 'wp-fort'));
    }
    
    /**
     * Make Cloudflare API request
     */
    private function api_request($endpoint, $data = array(), $method = 'GET') {
        if (!$this->is_configured()) {
            return new WP_Error('not_configured', __('Cloudflare API is not configured.', 'wp-fort'));
        }
        
        $url = $this->api_base . $endpoint;
        $args = array(
            'headers' => array(
                'X-Auth-Email' => $this->options['cloudflare_email'],
                'X-Auth-Key' => $this->options['cloudflare_api_key'],
                'Content-Type' => 'application/json'
            ),
            'timeout' => 30
        );
        
        if ($method === 'POST' || $method === 'PUT') {
            $args['body'] = json_encode($data);
            $args['method'] = $method;
        } elseif ($method === 'GET' && !empty($data)) {
            $url .= '?' . http_build_query($data);
        } elseif ($method === 'DELETE') {
            $args['method'] = 'DELETE';
        }
        
        $response = wp_remote_request($url, $args);
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        $body = wp_remote_retrieve_body($response);
        $decoded = json_decode($body, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            return new WP_Error('json_error', __('Invalid JSON response from Cloudflare.', 'wp-fort'));
        }
        
        return $decoded;
    }
    
    /**
     * Check if Cloudflare is configured
     */
    public function is_configured() {
        return $this->options['cloudflare_enabled'] &&
               !empty($this->options['cloudflare_email']) &&
               !empty($this->options['cloudflare_api_key']) &&
               !empty($this->options['cloudflare_zone_id']);
    }
    
    /**
     * Get Cloudflare zone settings
     */
    public function get_zone_settings() {
        if (!$this->is_configured()) {
            return new WP_Error('not_configured', __('Cloudflare API is not configured.', 'wp-fort'));
        }
        
        $response = $this->api_request(
            'zones/' . $this->options['cloudflare_zone_id'] . '/settings'
        );
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        if (isset($response['success']) && $response['success']) {
            return $response['result'];
        }
        
        return new WP_Error('api_error', __('Failed to fetch zone settings.', 'wp-fort'));
    }
    
    /**
     * Update Cloudflare security level
     */
    public function update_security_level($level = 'medium') {
        if (!$this->is_configured()) {
            return new WP_Error('not_configured', __('Cloudflare API is not configured.', 'wp-fort'));
        }
        
        $valid_levels = array('off', 'essentially_off', 'low', 'medium', 'high', 'under_attack');
        if (!in_array($level, $valid_levels)) {
            return new WP_Error('invalid_level', __('Invalid security level.', 'wp-fort'));
        }
        
        $response = $this->api_request(
            'zones/' . $this->options['cloudflare_zone_id'] . '/settings/security_level',
            array('value' => $level),
            'PATCH'
        );
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        if (isset($response['success']) && $response['success']) {
            return $response['result'];
        }
        
        return new WP_Error('api_error', __('Failed to update security level.', 'wp-fort'));
    }
    
    /**
     * Enable Cloudflare under attack mode
     */
    public function enable_under_attack_mode($enable = true) {
        return $this->update_security_level($enable ? 'under_attack' : 'medium');
    }
    
    /**
     * Purge Cloudflare cache
     */
    public function purge_cache($purge_everything = true) {
        if (!$this->is_configured()) {
            return new WP_Error('not_configured', __('Cloudflare API is not configured.', 'wp-fort'));
        }
        
        $data = $purge_everything ? array('purge_everything' => true) : array();
        
        $response = $this->api_request(
            'zones/' . $this->options['cloudflare_zone_id'] . '/purge_cache',
            $data,
            'POST'
        );
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        if (isset($response['success']) && $response['success']) {
            return true;
        }
        
        return new WP_Error('api_error', __('Failed to purge cache.', 'wp-fort'));
    }
    
    /**
     * Get Cloudflare statistics
     */
    public function get_statistics() {
        if (!$this->is_configured()) {
            return array(
                'configured' => false,
                'message' => 'Cloudflare not configured'
            );
        }
        
        $stats = array(
            'configured' => true,
            'zone_info' => array(),
            'threats_blocked' => 0,
            'bandwidth_saved' => 0,
            'requests_served' => 0
        );
        
        // Get zone info
        $zone_info = $this->test_connection();
        if (!is_wp_error($zone_info)) {
            $stats['zone_info'] = $zone_info;
        }
        
        // Get analytics for last 7 days
        $analytics = $this->get_analytics('-7 days');
        if (!is_wp_error($analytics)) {
            $stats['threats_blocked'] = $analytics['totals']['threats'] ?? 0;
            $stats['bandwidth_saved'] = $analytics['totals']['bandwidth']['cached'] ?? 0;
            $stats['requests_served'] = $analytics['totals']['requests']['cached'] ?? 0;
        }
        
        return $stats;
    }
}