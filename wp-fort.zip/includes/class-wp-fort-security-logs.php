<?php
/**
 * WP Fort Security Logs Class
 * 
 * @package WP_Fort
 * @since 1.0.0
 */

class WP_Fort_Security_Logs {
    
    private $core;
    private $options;
    
    public function __construct() {
        $this->core = WP_Fort_Core::get_instance();
        $this->options = $this->core->get_options();
        
        $this->init_hooks();
    }
    
    private function init_hooks() {
        // Schedule log cleanup
        add_action('wp_fort_cleanup_old_logs', array($this, 'cleanup_old_logs'));
        
        // Initialize scheduler
        add_action('init', array($this, 'init_scheduler'));
    }
    
    /**
     * Check if security logs table exists
     */
    private function table_exists() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'wp_fort_security_logs';
        return $wpdb->get_var("SHOW TABLES LIKE '$table_name'") == $table_name;
    }
    
    /**
     * Initialize scheduler for log cleanup
     */
    public function init_scheduler() {
        if (!wp_next_scheduled('wp_fort_cleanup_old_logs')) {
            wp_schedule_event(time(), 'daily', 'wp_fort_cleanup_old_logs');
        }
    }
    
    /**
     * Log security event
     */
    public function log_event($event_type, $ip_address, $username = '', $user_agent = '', $details = '', $severity = 'low') {
        if (!$this->options['logging_enabled'] || !$this->table_exists()) {
            return false;
        }
        
        global $wpdb;
        
        $geo_data = $this->get_geo_location($ip_address);
        
        $result = $wpdb->insert(
            $wpdb->prefix . 'wp_fort_security_logs',
            array(
                'timestamp' => current_time('mysql'),
                'event_type' => $event_type,
                'ip_address' => $ip_address,
                'username' => $username,
                'user_agent' => $user_agent,
                'request_url' => $_SERVER['REQUEST_URI'] ?? '',
                'country' => $geo_data['country'] ?? '',
                'region' => $geo_data['region'] ?? '',
                'city' => $geo_data['city'] ?? '',
                'details' => is_array($details) ? wp_json_encode($details) : $details,
                'severity' => $severity
            ),
            array('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')
        );
        
        return $result !== false;
    }
    
    /**
     * Get security logs with pagination
     */
    public function get_logs($args = array()) {
        global $wpdb;
        
        // Return empty results if table doesn't exist
        if (!$this->table_exists()) {
            return array(
                'logs' => array(),
                'total' => 0,
                'total_pages' => 0,
                'current_page' => $args['page'] ?? 1
            );
        }
        
        $defaults = array(
            'page' => 1,
            'per_page' => 20,
            'event_type' => '',
            'severity' => '',
            'ip_address' => '',
            'date_from' => '',
            'date_to' => '',
            'orderby' => 'timestamp',
            'order' => 'DESC'
        );
        
        $args = wp_parse_args($args, $defaults);
        
        $where = array();
        $prepare_args = array();
        
        // Build WHERE clause
        if (!empty($args['event_type'])) {
            $where[] = 'event_type = %s';
            $prepare_args[] = $args['event_type'];
        }
        
        if (!empty($args['severity'])) {
            $where[] = 'severity = %s';
            $prepare_args[] = $args['severity'];
        }
        
        if (!empty($args['ip_address'])) {
            $where[] = 'ip_address = %s';
            $prepare_args[] = $args['ip_address'];
        }
        
        if (!empty($args['date_from'])) {
            $where[] = 'timestamp >= %s';
            $prepare_args[] = $args['date_from'];
        }
        
        if (!empty($args['date_to'])) {
            $where[] = 'timestamp <= %s';
            $prepare_args[] = $args['date_to'];
        }
        
        $where_sql = '';
        if (!empty($where)) {
            $where_sql = 'WHERE ' . implode(' AND ', $where);
        }
        
        // Build ORDER BY clause
        $orderby = in_array($args['orderby'], array('timestamp', 'event_type', 'ip_address', 'severity')) ? 
                   $args['orderby'] : 'timestamp';
        $order = strtoupper($args['order']) === 'ASC' ? 'ASC' : 'DESC';
        $order_sql = "ORDER BY {$orderby} {$order}";
        
        // Calculate offset
        $offset = ($args['page'] - 1) * $args['per_page'];
        
        // Get logs
        $logs = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}wp_fort_security_logs 
                 {$where_sql} 
                 {$order_sql} 
                 LIMIT %d OFFSET %d",
                array_merge($prepare_args, array($args['per_page'], $offset))
            ),
            ARRAY_A
        );
        
        // Get total count
        $total = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}wp_fort_security_logs {$where_sql}",
                $prepare_args
            )
        );
        
        return array(
            'logs' => $logs,
            'total' => $total,
            'total_pages' => ceil($total / $args['per_page']),
            'current_page' => $args['page']
        );
    }
    
    /**
     * Get log statistics
     */
    public function get_statistics($period = '30 days') {
        global $wpdb;
        
        // Return empty stats if table doesn't exist
        if (!$this->table_exists()) {
            return array(
                'total_events' => 0,
                'events_by_type' => array(),
                'events_by_severity' => array(),
                'top_ips' => array(),
                'events_timeline' => array()
            );
        }
        
        $date_cutoff = date('Y-m-d H:i:s', strtotime('-' . $period));
        
        $stats = array(
            'total_events' => 0,
            'events_by_type' => array(),
            'events_by_severity' => array(),
            'top_ips' => array(),
            'events_timeline' => array()
        );
        
        // Total events
        $stats['total_events'] = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}wp_fort_security_logs 
                 WHERE timestamp >= %s",
                $date_cutoff
            )
        );
        
        // Events by type
        $events_by_type = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT event_type, COUNT(*) as count 
                 FROM {$wpdb->prefix}wp_fort_security_logs 
                 WHERE timestamp >= %s 
                 GROUP BY event_type 
                 ORDER BY count DESC",
                $date_cutoff
            ),
            ARRAY_A
        );
        
        foreach ($events_by_type as $event) {
            $stats['events_by_type'][$event['event_type']] = $event['count'];
        }
        
        // Events by severity
        $events_by_severity = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT severity, COUNT(*) as count 
                 FROM {$wpdb->prefix}wp_fort_security_logs 
                 WHERE timestamp >= %s 
                 GROUP BY severity",
                $date_cutoff
            ),
            ARRAY_A
        );
        
        foreach ($events_by_severity as $severity) {
            $stats['events_by_severity'][$severity['severity']] = $severity['count'];
        }
        
        // Top IPs
        $top_ips = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT ip_address, COUNT(*) as count 
                 FROM {$wpdb->prefix}wp_fort_security_logs 
                 WHERE timestamp >= %s 
                 GROUP BY ip_address 
                 ORDER BY count DESC 
                 LIMIT 10",
                $date_cutoff
            ),
            ARRAY_A
        );
        
        foreach ($top_ips as $ip) {
            $stats['top_ips'][$ip['ip_address']] = $ip['count'];
        }
        
        // Events timeline (last 7 days)
        $timeline = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT DATE(timestamp) as date, COUNT(*) as count 
                 FROM {$wpdb->prefix}wp_fort_security_logs 
                 WHERE timestamp >= %s 
                 GROUP BY DATE(timestamp) 
                 ORDER BY date DESC 
                 LIMIT 7",
                date('Y-m-d H:i:s', strtotime('-7 days'))
            ),
            ARRAY_A
        );
        
        foreach ($timeline as $day) {
            $stats['events_timeline'][$day['date']] = $day['count'];
        }
        
        return $stats;
    }
    
    /**
     * Cleanup old logs
     */
    public function cleanup_old_logs() {
        global $wpdb;
        
        if (!$this->table_exists()) {
            return 0;
        }
        
        $retention_days = $this->options['log_retention_days'] ?? 30;
        $cutoff_date = date('Y-m-d H:i:s', strtotime('-' . $retention_days . ' days'));
        
        $deleted = $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$wpdb->prefix}wp_fort_security_logs 
                 WHERE timestamp < %s",
                $cutoff_date
            )
        );
        
        return $deleted;
    }
    
    /**
     * Clear all logs
     */
    public function clear_all_logs() {
        global $wpdb;
        
        if (!$this->table_exists()) {
            return false;
        }
        
        $result = $wpdb->query("TRUNCATE TABLE {$wpdb->prefix}wp_fort_security_logs");
        
        return $result !== false;
    }
    
    /**
     * Export logs to CSV
     */
    public function export_logs($args = array()) {
        $logs_data = $this->get_logs(array_merge($args, array('per_page' => -1)));
        $logs = $logs_data['logs'];
        
        $filename = 'wp-fort-security-logs-' . date('Y-m-d-H-i-s') . '.csv';
        
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        
        $output = fopen('php://output', 'w');
        
        // Headers
        fputcsv($output, array(
            'Timestamp',
            'Event Type',
            'IP Address',
            'Username',
            'Country',
            'Region', 
            'City',
            'Severity',
            'User Agent',
            'Request URL',
            'Details'
        ));
        
        // Data
        foreach ($logs as $log) {
            fputcsv($output, array(
                $log['timestamp'],
                $log['event_type'],
                $log['ip_address'],
                $log['username'],
                $log['country'],
                $log['region'],
                $log['city'],
                $log['severity'],
                $log['user_agent'],
                $log['request_url'],
                $log['details']
            ));
        }
        
        fclose($output);
        exit;
    }
    
    /**
     * Get geo location for IP
     */
    private function get_geo_location($ip_address) {
        // Use the core method
        return $this->core->get_geo_location($ip_address);
    }
    
    /**
     * Get event types
     */
    public function get_event_types() {
        global $wpdb;
        
        if (!$this->table_exists()) {
            return array();
        }
        
        $event_types = $wpdb->get_col(
            "SELECT DISTINCT event_type FROM {$wpdb->prefix}wp_fort_security_logs ORDER BY event_type"
        );
        
        return $event_types;
    }
    
    /**
     * Get log count by severity
     */
    public function get_severity_counts() {
        global $wpdb;
        
        if (!$this->table_exists()) {
            return array(
                'critical' => 0,
                'high' => 0,
                'medium' => 0,
                'low' => 0
            );
        }
        
        $counts = $wpdb->get_results(
            "SELECT severity, COUNT(*) as count 
             FROM {$wpdb->prefix}wp_fort_security_logs 
             GROUP BY severity",
            ARRAY_A
        );
        
        $result = array(
            'critical' => 0,
            'high' => 0,
            'medium' => 0,
            'low' => 0
        );
        
        foreach ($counts as $count) {
            $result[$count['severity']] = $count['count'];
        }
        
        return $result;
    }
    
    /**
     * Get recent security events
     */
    public function get_recent_events($limit = 10) {
        global $wpdb;
        
        if (!$this->table_exists()) {
            return array();
        }
        
        $events = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}wp_fort_security_logs 
                 ORDER BY timestamp DESC 
                 LIMIT %d",
                $limit
            ),
            ARRAY_A
        );
        
        return $events;
    }
    
    /**
     * Get events count by type
     */
    public function get_events_count_by_type($event_type) {
        global $wpdb;
        
        if (!$this->table_exists()) {
            return 0;
        }
        
        $count = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}wp_fort_security_logs 
                 WHERE event_type = %s",
                $event_type
            )
        );
        
        return $count ?: 0;
    }
    
    /**
     * Get today's events count
     */
    public function get_todays_events_count() {
        global $wpdb;
        
        if (!$this->table_exists()) {
            return 0;
        }
        
        $count = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}wp_fort_security_logs 
                 WHERE DATE(timestamp) = %s",
                current_time('mysql')
            )
        );
        
        return $count ?: 0;
    }
}