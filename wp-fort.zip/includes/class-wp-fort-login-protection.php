<?php
/**
 * WP Fort Login Protection Class
 * 
 * @package WP_Fort
 * @since 1.0.0
 */

class WP_Fort_Login_Protection {
    
    private $core;
    private $options;
    private $login_attempts = array();
    
    public function __construct() {
        $this->core = WP_Fort_Core::get_instance();
        $this->options = $this->core->get_options();
        
        $this->init_hooks();
    }
    
    private function init_hooks() {
        // Early hooks for login protection
        add_action('init', array($this, 'check_login_access'), 1);
        add_action('login_init', array($this, 'handle_custom_login'));
        
        // Login attempt tracking
        add_action('wp_login_failed', array($this, 'track_login_failure'));
        add_action('wp_login', array($this, 'track_login_success'), 10, 2);
        
        // Security headers on login page
        add_action('login_head', array($this, 'add_login_security_headers'));
        
        // Hide login errors
        add_filter('login_errors', array($this, 'hide_login_errors'));
        
        // Limit login attempts
        add_filter('authenticate', array($this, 'check_login_attempts'), 30, 3);
    }
    
    /**
     * Check login access and block wp-login.php if enabled
     */
    public function check_login_access() {
        // Only proceed if we're accessing login-related URLs
        if (!$this->is_login_request()) {
            return;
        }
        
        $request_uri = $_SERVER['REQUEST_URI'] ?? '';
        $custom_slug = $this->options['custom_login_slug'] ?? '';
        
        // Block wp-login.php if custom URL is enabled and block setting is on
        if ($this->options['login_protection_enabled'] && 
            $this->options['block_wp_login'] && 
            strpos($request_uri, 'wp-login.php') !== false) {
            
            // Allow access only if it's our custom login URL
            if (empty($custom_slug) || strpos($request_uri, $custom_slug) === false) {
                $this->handle_blocked_login_access();
            }
        }
    }
    
    /**
     * Handle custom login URL
     */
    public function handle_custom_login() {
        if (!$this->options['login_protection_enabled'] || empty($this->options['custom_login_slug'])) {
            return;
        }
        
        $request_uri = $_SERVER['REQUEST_URI'] ?? '';
        $custom_slug = $this->options['custom_login_slug'];
        
        // Check if we're accessing the custom login URL
        $is_custom_login = strpos($request_uri, $custom_slug) !== false;
        
        if (!$is_custom_login && $this->options['block_wp_login']) {
            $this->handle_blocked_login_access();
        }
        
        // If it's custom login, ensure proper handling
        if ($is_custom_login) {
            $this->custom_login_processing();
        }
    }
    
    /**
     * Process custom login URL access
     */
    private function custom_login_processing() {
        // Add security checks for custom login
        $this->check_brute_force_protection();
        $this->check_ip_restrictions();
    }
    
    /**
     * Handle blocked login access
     */
    private function handle_blocked_login_access() {
        $ip = WP_Fort_Core::get_client_ip();
        $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        
        // Log the blocked attempt
        $this->core->log_security_event(
            'login_blocked', 
            $ip, 
            '', 
            $user_agent,
            array(
                'reason' => 'direct_wp_login_access',
                'request_uri' => $_SERVER['REQUEST_URI'] ?? ''
            )
        );
        
        // Show 404 or redirect
        if (wp_redirect(home_url('404'))) {
            exit;
        } else {
            status_header(404);
            nocache_headers();
            include get_404_template();
            exit;
        }
    }
    
    /**
     * Check if current request is login-related
     */
    private function is_login_request() {
        $request_uri = $_SERVER['REQUEST_URI'] ?? '';
        
        return strpos($request_uri, 'wp-login.php') !== false ||
               strpos($request_uri, 'wp-signup.php') !== false ||
               strpos($request_uri, $this->options['custom_login_slug'] ?? '') !== false;
    }
    
    /**
     * Track failed login attempts
     */
    public function track_login_failure($username) {
        if (!$this->options['log_failed_logins']) {
            return;
        }
        
        $ip = WP_Fort_Core::get_client_ip();
        $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        
        $this->core->log_security_event(
            'login_failed',
            $ip,
            $username,
            $user_agent,
            array(
                'reason' => 'invalid_credentials',
                'timestamp' => current_time('mysql')
            )
        );
        
        $this->increment_login_attempts($ip);
        
        // Check if we should block this IP
        $this->check_brute_force_protection($ip);
    }
    
    /**
     * Track successful logins
     */
    public function track_login_success($username, $user) {
        if (!$this->options['log_successful_logins']) {
            return;
        }
        
        // Only log admin/super admin logins
        if (!current_user_can('manage_options')) {
            return;
        }
        
        $ip = WP_Fort_Core::get_client_ip();
        $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        
        $this->core->log_security_event(
            'login_success',
            $ip,
            $username,
            $user_agent,
            array(
                'user_id' => $user->ID,
                'roles' => $user->roles,
                'timestamp' => current_time('mysql')
            )
        );
        
        // Reset login attempts on successful login
        $this->reset_login_attempts($ip);
    }
    
    /**
     * Increment login attempts for IP
     */
    private function increment_login_attempts($ip) {
        $transient_key = 'wp_fort_login_attempts_' . md5($ip);
        $attempts = get_transient($transient_key) ?: 0;
        $attempts++;
        
        set_transient($transient_key, $attempts, 15 * MINUTE_IN_SECONDS);
    }
    
    /**
     * Reset login attempts for IP
     */
    private function reset_login_attempts($ip) {
        $transient_key = 'wp_fort_login_attempts_' . md5($ip);
        delete_transient($transient_key);
    }
    
    /**
     * Get login attempts for IP
     */
    private function get_login_attempts($ip) {
        $transient_key = 'wp_fort_login_attempts_' . md5($ip);
        return get_transient($transient_key) ?: 0;
    }
    
    /**
     * Check brute force protection
     */
    private function check_brute_force_protection($ip = null) {
        if (!$this->options['brute_force_protection']) {
            return;
        }
        
        $ip = $ip ?: WP_Fort_Core::get_client_ip();
        $attempts = $this->get_login_attempts($ip);
        $max_attempts = $this->options['max_login_attempts'] ?? 5;
        
        if ($attempts >= $max_attempts) {
            $this->handle_brute_force_detected($ip, $attempts);
        }
    }
    
    /**
     * Handle detected brute force attack
     */
    private function handle_brute_force_detected($ip, $attempts) {
        // Log the brute force attempt
        $this->core->log_security_event(
            'brute_force_detected',
            $ip,
            '',
            $_SERVER['HTTP_USER_AGENT'] ?? '',
            array(
                'attempts' => $attempts,
                'max_attempts' => $this->options['max_login_attempts'] ?? 5,
                'timestamp' => current_time('mysql')
            )
        );
        
        // Block the IP temporarily
        $block_duration = ($this->options['lockout_duration'] ?? 30) * MINUTE_IN_SECONDS;
        $block_key = 'wp_fort_ip_blocked_' . md5($ip);
        set_transient($block_key, true, $block_duration);
        
        // Slow down responses
        sleep(min($attempts - $this->options['max_login_attempts'] + 1, 10));
        
        // Show error message
        wp_die(
            __('Too many login attempts. Please try again later.', 'wp-fort'),
            __('Login Blocked', 'wp-fort'),
            array('response' => 429)
        );
    }
    
    /**
     * Check login attempts during authentication
     */
    public function check_login_attempts($user, $username, $password) {
        if (!$this->options['brute_force_protection']) {
            return $user;
        }
        
        $ip = WP_Fort_Core::get_client_ip();
        $block_key = 'wp_fort_ip_blocked_' . md5($ip);
        
        // Check if IP is temporarily blocked
        if (get_transient($block_key)) {
            return new WP_Error(
                'ip_blocked',
                __('Too many login attempts. Please try again later.', 'wp-fort')
            );
        }
        
        return $user;
    }
    
    /**
     * Check IP restrictions for login
     */
    private function check_ip_restrictions() {
        if (!$this->options['ip_restriction_enabled'] || empty($this->options['allowed_ips'])) {
            return;
        }
        
        $current_ip = WP_Fort_Core::get_client_ip();
        $allowed_ips = $this->options['allowed_ips'];
        
        if (!in_array($current_ip, $allowed_ips)) {
            $this->handle_ip_restriction_violation($current_ip);
        }
    }
    
    /**
     * Handle IP restriction violation
     */
    private function handle_ip_restriction_violation($ip) {
        $this->core->log_security_event(
            'ip_restriction_violation',
            $ip,
            '',
            $_SERVER['HTTP_USER_AGENT'] ?? '',
            array(
                'reason' => 'ip_not_in_whitelist',
                'allowed_ips' => $this->options['allowed_ips'],
                'timestamp' => current_time('mysql')
            )
        );
        
        wp_die(
            __('Access denied. Your IP address is not authorized to access this page.', 'wp-fort'),
            __('Access Denied', 'wp-fort'),
            array('response' => 403)
        );
    }
    
    /**
     * Add security headers to login page
     */
    public function add_login_security_headers() {
        if (!headers_sent()) {
            header('X-Frame-Options: SAMEORIGIN');
            header('X-Content-Type-Options: nosniff');
            header('X-XSS-Protection: 1; mode=block');
        }
    }
    
    /**
     * Hide login errors to prevent username enumeration
     */
    public function hide_login_errors($error) {
        if (in_array($error, array(
            __('<strong>Error</strong>: The username or password you entered is incorrect.'),
            __('<strong>Error</strong>: Invalid username.'),
            __('<strong>Error</strong>: The password you entered for the username %s is incorrect.')
        ), true)) {
            return __('<strong>Error</strong>: Invalid login credentials.');
        }
        
        return $error;
    }
    
    /**
     * Get custom login URL
     */
    public function get_custom_login_url() {
        if (!$this->options['login_protection_enabled'] || empty($this->options['custom_login_slug'])) {
            return wp_login_url();
        }
        
        return home_url($this->options['custom_login_slug']);
    }
    
    /**
     * Validate custom login slug
     */
    public function validate_custom_slug($slug) {
        // Check if slug is valid
        if (empty($slug) || !preg_match('/^[a-z0-9_-]+$/', $slug)) {
            return false;
        }
        
        // Check if slug conflicts with existing routes
        $reserved_slugs = array(
            'admin', 'wp-admin', 'wp-login', 'login', 'dashboard',
            'feed', 'comments', 'search', 'author', 'category'
        );
        
        if (in_array($slug, $reserved_slugs)) {
            return false;
        }
        
        return true;
    }
}