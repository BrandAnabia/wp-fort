<?php
/**
 * WP Fort IP Manager Class
 * 
 * @package WP_Fort
 * @since 1.0.0
 */

class WP_Fort_IP_Manager {
    
    private $core;
    private $options;
    
    public function __construct() {
        $this->core = WP_Fort_Core::get_instance();
        $this->options = $this->core->get_options();
        
        $this->init_hooks();
    }
    
    private function init_hooks() {
        // IP restriction checks
        add_action('admin_init', array($this, 'check_admin_ip_restriction'));
        
        // REST API IP restrictions
        add_filter('rest_authentication_errors', array($this, 'check_rest_api_ip_restriction'));
    }
    
    /**
     * Check IP restrictions for admin area
     */
    public function check_admin_ip_restriction() {
        // Skip for AJAX requests
        if (wp_doing_ajax()) {
            return;
        }
        
        // Skip if IP restriction is disabled
        if (!$this->options['ip_restriction_enabled'] || empty($this->options['allowed_ips'])) {
            return;
        }
        
        // Skip for users who can manage options (admins)
        if (current_user_can('manage_options')) {
            return;
        }
        
        $current_ip = WP_Fort_Core::get_client_ip();
        $allowed_ips = $this->options['allowed_ips'];
        
        if (!$this->is_ip_allowed($current_ip, $allowed_ips)) {
            $this->handle_admin_ip_restriction($current_ip);
        }
    }
    
    /**
     * Check IP restrictions for REST API
     */
    public function check_rest_api_ip_restriction($result) {
        if (!$this->options['ip_restriction_enabled'] || empty($this->options['allowed_ips'])) {
            return $result;
        }
        
        // Skip if already authenticated
        if (is_user_logged_in()) {
            return $result;
        }
        
        $current_ip = WP_Fort_Core::get_client_ip();
        $allowed_ips = $this->options['allowed_ips'];
        
        if (!$this->is_ip_allowed($current_ip, $allowed_ips)) {
            return new WP_Error(
                'rest_ip_restricted',
                __('Access denied. Your IP address is not authorized.', 'wp-fort'),
                array('status' => 403)
            );
        }
        
        return $result;
    }
    
    /**
     * Check if IP is allowed
     */
    public function is_ip_allowed($ip, $allowed_ips = null) {
        if ($allowed_ips === null) {
            $allowed_ips = $this->options['allowed_ips'] ?? array();
        }
        
        // Always allow localhost
        if ($ip === '127.0.0.1' || $ip === '::1') {
            return true;
        }
        
        foreach ($allowed_ips as $allowed_ip) {
            if ($this->check_ip_match($ip, $allowed_ip)) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Check if IP matches pattern (supports CIDR notation)
     */
    private function check_ip_match($ip, $pattern) {
        // Exact match
        if ($ip === $pattern) {
            return true;
        }
        
        // CIDR notation match
        if (strpos($pattern, '/') !== false) {
            return $this->check_cidr_match($ip, $pattern);
        }
        
        // Wildcard match (e.g., 192.168.*)
        if (strpos($pattern, '*') !== false) {
            return $this->check_wildcard_match($ip, $pattern);
        }
        
        return false;
    }
    
    /**
     * Check CIDR notation match
     */
    private function check_cidr_match($ip, $cidr) {
        list($subnet, $bits) = explode('/', $cidr);
        
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
            return $this->check_ipv4_cidr($ip, $subnet, $bits);
        }
        
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
            return $this->check_ipv6_cidr($ip, $subnet, $bits);
        }
        
        return false;
    }
    
    /**
     * Check IPv4 CIDR match
     */
    private function check_ipv4_cidr($ip, $subnet, $bits) {
        $ip = ip2long($ip);
        $subnet = ip2long($subnet);
        $mask = -1 << (32 - $bits);
        
        return ($ip & $mask) === ($subnet & $mask);
    }
    
    /**
     * Check IPv6 CIDR match
     */
    private function check_ipv6_cidr($ip, $subnet, $bits) {
        // Simplified IPv6 CIDR check
        $ip_bin = inet_pton($ip);
        $subnet_bin = inet_pton($subnet);
        
        // Compare the first $bits bits
        $bytes = intval($bits / 8);
        $bits_remain = $bits % 8;
        
        // Compare full bytes
        if (strncmp($ip_bin, $subnet_bin, $bytes) !== 0) {
            return false;
        }
        
        // Compare remaining bits
        if ($bits_remain > 0) {
            $ip_byte = ord($ip_bin[$bytes]);
            $subnet_byte = ord($subnet_bin[$bytes]);
            $mask = 0xFF << (8 - $bits_remain);
            
            return ($ip_byte & $mask) === ($subnet_byte & $mask);
        }
        
        return true;
    }
    
    /**
     * Check wildcard match
     */
    private function check_wildcard_match($ip, $pattern) {
        $pattern = preg_quote($pattern, '/');
        $pattern = str_replace('\*', '.*', $pattern);
        $pattern = '/^' . $pattern . '$/';
        
        return preg_match($pattern, $ip) === 1;
    }
    
    /**
     * Handle admin IP restriction violation
     */
    private function handle_admin_ip_restriction($ip) {
        $this->core->log_security_event(
            'admin_ip_restriction_violation',
            $ip,
            is_user_logged_in() ? wp_get_current_user()->user_login : '',
            $_SERVER['HTTP_USER_AGENT'] ?? '',
            array(
                'reason' => 'ip_not_in_admin_whitelist',
                'allowed_ips' => $this->options['allowed_ips'],
                'timestamp' => current_time('mysql')
            )
        );
        
        wp_die(
            __('Access denied. Your IP address is not authorized to access the admin area.', 'wp-fort'),
            __('Access Denied', 'wp-fort'),
            array('response' => 403)
        );
    }
    
    /**
     * Add IP to whitelist
     */
    public function add_ip($ip) {
        if (!filter_var($ip, FILTER_VALIDATE_IP)) {
            return new WP_Error('invalid_ip', __('Invalid IP address.', 'wp-fort'));
        }
        
        $options = $this->core->get_options();
        
        if (!in_array($ip, $options['allowed_ips'])) {
            $options['allowed_ips'][] = $ip;
            $this->core->update_options($options);
            
            return true;
        }
        
        return new WP_Error('ip_exists', __('IP address already in whitelist.', 'wp-fort'));
    }
    
    /**
     * Remove IP from whitelist
     */
    public function remove_ip($ip) {
        $options = $this->core->get_options();
        
        if (($key = array_search($ip, $options['allowed_ips'])) !== false) {
            unset($options['allowed_ips'][$key]);
            $options['allowed_ips'] = array_values($options['allowed_ips']);
            $this->core->update_options($options);
            
            return true;
        }
        
        return new WP_Error('ip_not_found', __('IP address not found in whitelist.', 'wp-fort'));
    }
    
    /**
     * Get all whitelisted IPs
     */
    public function get_whitelisted_ips() {
        return $this->options['allowed_ips'] ?? array();
    }
    
    /**
     * Validate IP address
     */
    public function validate_ip($ip) {
        return filter_var($ip, FILTER_VALIDATE_IP) !== false;
    }
    
    /**
     * Get IP information
     */
    public function get_ip_info($ip) {
        $info = array(
            'ip' => $ip,
            'type' => filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) ? 'IPv4' : 
                     (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) ? 'IPv6' : 'Invalid'),
            'is_private' => $this->is_private_ip($ip),
            'is_whitelisted' => $this->is_ip_allowed($ip)
        );
        
        return $info;
    }
    
    /**
     * Check if IP is private
     */
    private function is_private_ip($ip) {
        $private_ranges = array(
            '10.0.0.0/8',
            '172.16.0.0/12', 
            '192.168.0.0/16',
            '127.0.0.0/8',
            '::1/128',
            'fc00::/7'
        );
        
        foreach ($private_ranges as $range) {
            if ($this->check_cidr_match($ip, $range)) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Get IP reputation (placeholder for future integration)
     */
    public function get_ip_reputation($ip) {
        // This could integrate with services like AbuseIPDB, IPQualityScore, etc.
        return array(
            'score' => 0,
            'abuse_confidence' => 0,
            'is_malicious' => false,
            'threat_types' => array()
        );
    }
}