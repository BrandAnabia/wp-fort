<?php
/**
 * WP Fort Core Security Class
 * 
 * @package WP_Fort
 * @since 1.0.0
 */

class WP_Fort_Core {
    
    private static $instance = null;
    private $options;
    
    public function __construct() {
        $this->load_options();
        $this->init_hooks();
    }
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function load_options() {
        $defaults = array(
            // Login Protection
            'login_protection_enabled' => true,
            'custom_login_slug' => 'secure-admin',
            'block_wp_login' => true,
            
            // IP Restrictions
            'ip_restriction_enabled' => false,
            'allowed_ips' => array(),
            'ip_whitelist' => array(),
            
            // Security Logging
            'logging_enabled' => true,
            'log_retention_days' => 30,
            'log_failed_logins' => true,
            'log_successful_logins' => true,
            
            // Firewall
            'firewall_enabled' => true,
            'block_suspicious_requests' => true,
            'prevent_php_execution' => true,
            
            // Brute Force Protection
            'brute_force_protection' => true,
            'max_login_attempts' => 5,
            'lockout_duration' => 30, // minutes
            
            // Cloudflare
            'cloudflare_enabled' => false,
            'cloudflare_api_key' => '',
            'cloudflare_email' => '',
            'cloudflare_zone_id' => '',
            
            // General Settings
            'disable_xmlrpc' => true,
            'hide_wp_version' => true,
            'disable_file_edit' => true,
        );
        
        $this->options = wp_parse_args(get_option('wp_fort_settings'), $defaults);
    }
    
    private function init_hooks() {
        add_action('init', array($this, 'security_headers'));
        add_action('wp_loaded', array($this, 'early_security_checks'));
        add_filter('rest_authentication_errors', array($this, 'rest_api_protection'));
        
        // WordPress hardening
        if ($this->options['disable_xmlrpc']) {
            add_filter('xmlrpc_enabled', '__return_false');
        }
        
        if ($this->options['hide_wp_version']) {
            remove_action('wp_head', 'wp_generator');
            add_filter('the_generator', '__return_empty_string');
        }
        
        // Only define DISALLOW_FILE_EDIT if not already defined and setting is enabled
        if ($this->options['disable_file_edit'] && !defined('DISALLOW_FILE_EDIT')) {
            define('DISALLOW_FILE_EDIT', true);
        }
        
        // Check if table exists and create if needed
        add_action('admin_init', array($this, 'check_table_exists'));
    }
    
    /**
     * Check if security logs table exists and create if needed
     */
    public function check_table_exists() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'wp_fort_security_logs';
        
        // Check if table exists
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
            // Table doesn't exist, create it
            $this->create_logs_table();
        }
    }
    
    /**
     * Plugin activation
     */
    public static function activate() {
        // Create default options
        if (!get_option('wp_fort_settings')) {
            $defaults = array(
                'login_protection_enabled' => true,
                'custom_login_slug' => 'secure-admin-' . wp_generate_password(8, false),
                'block_wp_login' => true,
                'logging_enabled' => true,
                'firewall_enabled' => true,
                'brute_force_protection' => true,
                'disable_xmlrpc' => true,
                'hide_wp_version' => true,
                'disable_file_edit' => true,
            );
            update_option('wp_fort_settings', $defaults);
        }
        
        // Create security logs table
        self::create_logs_table();
        
        // Add current IP to whitelist
        self::add_current_ip_to_whitelist();
    }
    
    /**
     * Plugin deactivation
     */
    public static function deactivate() {
        // Clean up temporary data
        wp_clear_scheduled_hook('wp_fort_cleanup_old_logs');
        
        // Don't remove settings so configuration is preserved
    }
    
    /**
     * Create security logs table
     */
    private static function create_logs_table() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'wp_fort_security_logs';
        
        // Check if table already exists
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") == $table_name) {
            return true;
        }
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // Use a simpler SQL syntax that's more compatible
        $sql = "CREATE TABLE $table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            timestamp datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
            event_type varchar(100) NOT NULL,
            ip_address varchar(45) NOT NULL,
            username varchar(255) DEFAULT '',
            user_agent text,
            request_url text,
            country varchar(100) DEFAULT '',
            region varchar(100) DEFAULT '',
            city varchar(100) DEFAULT '',
            details text,
            severity varchar(20) DEFAULT 'low',
            PRIMARY KEY (id),
            KEY event_type (event_type),
            KEY ip_address (ip_address),
            KEY timestamp (timestamp),
            KEY severity (severity)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        
        $result = dbDelta($sql);
        
        // Check if table was created successfully
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
            // Log error if table creation failed
            error_log('WP Fort: Failed to create security logs table');
            return false;
        }
        
        return true;
    }
    
    /**
     * Add current IP to whitelist during activation
     */
    private static function add_current_ip_to_whitelist() {
        $current_ip = self::get_client_ip();
        $settings = get_option('wp_fort_settings', array());
        
        if (!isset($settings['allowed_ips'])) {
            $settings['allowed_ips'] = array();
        }
        
        if (!in_array($current_ip, $settings['allowed_ips'])) {
            $settings['allowed_ips'][] = $current_ip;
            update_option('wp_fort_settings', $settings);
        }
    }
    
    /**
     * Get client IP address
     */
    public static function get_client_ip() {
        $ip_keys = array(
            'HTTP_X_REAL_IP',
            'HTTP_X_FORWARDED_FOR',
            'HTTP_CF_CONNECTING_IP', // Cloudflare
            'HTTP_CLIENT_IP',
            'REMOTE_ADDR'
        );
        
        foreach ($ip_keys as $key) {
            if (!empty($_SERVER[$key])) {
                $ip = trim($_SERVER[$key]);
                // Handle multiple IPs in X_FORWARDED_FOR
                if (strpos($ip, ',') !== false) {
                    $ip_entries = explode(',', $ip);
                    $ip = trim($ip_entries[0]);
                }
                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                    return $ip;
                }
            }
        }
        
        return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    }
    
    /**
     * Security headers
     */
    public function security_headers() {
        if (!headers_sent()) {
            header('X-Content-Type-Options: nosniff');
            header('X-Frame-Options: SAMEORIGIN');
            header('X-XSS-Protection: 1; mode=block');
            
            // Strict Transport Security if SSL
            if (is_ssl()) {
                header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
            }
            
            // Referrer Policy
            header('Referrer-Policy: strict-origin-when-cross-origin');
        }
    }
    
    /**
     * Early security checks
     */
    public function early_security_checks() {
        $this->block_suspicious_user_agents();
        $this->prevent_php_execution_in_uploads();
    }
    
    /**
     * Block suspicious user agents
     */
    private function block_suspicious_user_agents() {
        if (!isset($_SERVER['HTTP_USER_AGENT'])) {
            return;
        }
        
        $user_agent = $_SERVER['HTTP_USER_AGENT'];
        $suspicious_patterns = array(
            'nmap', 'nikto', 'sqlmap', 'wpscan', 'acunetix', 
            'nessus', 'metasploit', 'havij', 'zap'
        );
        
        foreach ($suspicious_patterns as $pattern) {
            if (stripos($user_agent, $pattern) !== false) {
                $this->log_security_event('suspicious_user_agent', self::get_client_ip(), '', $user_agent);
                wp_die('Access denied.', 403);
            }
        }
    }
    
    /**
     * Prevent PHP execution in uploads
     */
    private function prevent_php_execution_in_uploads() {
        // This will be handled by the firewall class
        // Keeping this as a placeholder for future implementation
    }
    
    /**
     * REST API protection
     */
    public function rest_api_protection($result) {
        if (!is_user_logged_in() && $this->options['disable_xmlrpc']) {
            // Allow only specific public endpoints
            $allowed_endpoints = array(
                '/wp/v2/posts',
                '/wp/v2/pages',
                '/wp/v2/categories',
                '/wp/v2/tags'
            );
            
            $request_uri = $_SERVER['REQUEST_URI'] ?? '';
            $is_allowed = false;
            
            foreach ($allowed_endpoints as $endpoint) {
                if (strpos($request_uri, $endpoint) !== false) {
                    $is_allowed = true;
                    break;
                }
            }
            
            if (!$is_allowed) {
                return new WP_Error('rest_disabled', __('REST API access disabled.'), array('status' => 403));
            }
        }
        
        return $result;
    }
    
    /**
     * Log security events
     */
    public function log_security_event($event_type, $ip_address, $username = '', $user_agent = '', $details = '') {
        if (!$this->options['logging_enabled']) {
            return;
        }
        
        global $wpdb;
        
        // Check if table exists before logging
        $table_name = $wpdb->prefix . 'wp_fort_security_logs';
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
            return; // Table doesn't exist, skip logging
        }
        
        $geo_data = $this->get_geo_location($ip_address);
        
        $wpdb->insert(
            $table_name,
            array(
                'timestamp' => current_time('mysql'),
                'event_type' => $event_type,
                'ip_address' => $ip_address,
                'username' => $username,
                'user_agent' => $user_agent,
                'request_url' => $_SERVER['REQUEST_URI'] ?? '',
                'country' => $geo_data['country'] ?? '',
                'region' => $geo_data['region'] ?? '',
                'city' => $geo_data['city'] ?? '',
                'details' => is_array($details) ? json_encode($details) : $details,
                'severity' => $this->get_event_severity($event_type)
            ),
            array('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')
        );
    }
    
    /**
     * Get geo location data
     */
    private function get_geo_location($ip_address) {
        // Simple IP geolocation - can be enhanced with paid services
        if ($ip_address === '127.0.0.1' || strpos($ip_address, '192.168.') === 0) {
            return array('country' => 'Local', 'region' => 'Internal', 'city' => 'Local Network');
        }
        
        // Free IP geolocation using ipapi.co
        $transient_key = 'wp_fort_geo_' . md5($ip_address);
        $geo_data = get_transient($transient_key);
        
        if ($geo_data === false) {
            $response = wp_remote_get('http://ipapi.co/' . $ip_address . '/json/');
            
            if (!is_wp_error($response) && $response['response']['code'] === 200) {
                $data = json_decode($response['body'], true);
                $geo_data = array(
                    'country' => $data['country_name'] ?? 'Unknown',
                    'region' => $data['region'] ?? 'Unknown',
                    'city' => $data['city'] ?? 'Unknown'
                );
                set_transient($transient_key, $geo_data, WEEK_IN_SECONDS);
            } else {
                $geo_data = array('country' => 'Unknown', 'region' => 'Unknown', 'city' => 'Unknown');
            }
        }
        
        return $geo_data;
    }
    
    /**
     * Get event severity level
     */
    private function get_event_severity($event_type) {
        $severity_map = array(
            'login_success' => 'low',
            'login_failed' => 'medium',
            'ip_blocked' => 'high',
            'brute_force_detected' => 'critical',
            'suspicious_request' => 'high',
            'file_change_detected' => 'high'
        );
        
        return $severity_map[$event_type] ?? 'low';
    }
    
    /**
     * Get plugin options
     */
    public function get_options() {
        return $this->options;
    }
    
    /**
     * Update plugin options
     */
    public function update_options($new_options) {
        $this->options = wp_parse_args($new_options, $this->options);
        update_option('wp_fort_settings', $this->options);
    }
    
    /**
     * Check if security logs table exists
     */
    public function table_exists() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'wp_fort_security_logs';
        return $wpdb->get_var("SHOW TABLES LIKE '$table_name'") == $table_name;
    }
}