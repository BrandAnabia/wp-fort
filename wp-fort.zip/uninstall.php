<?php
/**
 * WP Fort Uninstaller
 * 
 * @package WP_Fort
 * @since 1.0.0
 */

// Prevent direct access
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Check if we should remove all data
$remove_data = get_option('wp_fort_remove_data_on_uninstall', false);

if (!$remove_data) {
    return;
}

global $wpdb;

// Remove options
delete_option('wp_fort_settings');
delete_option('wp_fort_encryption_key');
delete_option('wp_fort_remove_data_on_uninstall');
delete_option('wp_fort_version');

// Remove security logs table
$table_name = $wpdb->prefix . 'wp_fort_security_logs';
$wpdb->query("DROP TABLE IF EXISTS $table_name");

// Clear any scheduled events
wp_clear_scheduled_hook('wp_fort_cleanup_old_logs');

// Remove transients
$wpdb->query(
    "DELETE FROM $wpdb->options 
     WHERE option_name LIKE '%wp_fort_%' 
     OR option_name LIKE '%_transient_wp_fort_%' 
     OR option_name LIKE '%_transient_timeout_wp_fort_%'"
);

// Remove user meta if any
$wpdb->query(
    "DELETE FROM $wpdb->usermeta 
     WHERE meta_key LIKE 'wp_fort_%'"
);