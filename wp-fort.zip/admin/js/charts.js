/**
 * WP Fort Charts JavaScript
 * 
 * @package WP_Fort
 * @since 1.0.0
 */

(function($) {
    'use strict';

    class WPFortCharts {
        constructor() {
            this.charts = {};
            this.init();
        }

        init() {
            this.initSeverityChart();
            this.initEventsTimeline();
            this.initAttackTypesChart();
        }

        initSeverityChart() {
            const $chart = $('#severity-chart');
            if (!$chart.length) return;

            // Get data from the page (this would typically come from AJAX)
            const severityData = this.getSeverityData();
            
            // Create chart using Chart.js
            const ctx = $chart[0].getContext('2d');
            this.charts.severity = new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: [
                        'Critical',
                        'High', 
                        'Medium',
                        'Low'
                    ],
                    datasets: [{
                        data: [
                            severityData.critical,
                            severityData.high,
                            severityData.medium,
                            severityData.low
                        ],
                        backgroundColor: [
                            '#d63638', // Critical - Red
                            '#dba617', // High - Orange
                            '#00a32a', // Medium - Green
                            '#2271b1'  // Low - Blue
                        ],
                        borderWidth: 2,
                        borderColor: '#fff'
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom',
                            labels: {
                                padding: 20,
                                usePointStyle: true
                            }
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    const label = context.label || '';
                                    const value = context.parsed;
                                    const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                    const percentage = total > 0 ? Math.round((value / total) * 100) : 0;
                                    return `${label}: ${value} (${percentage}%)`;
                                }
                            }
                        }
                    },
                    cutout: '60%'
                }
            });
        }

        initEventsTimeline() {
            const $chart = $('#events-timeline-chart');
            if (!$chart.length) return;

            const timelineData = this.getTimelineData();
            
            const ctx = $chart[0].getContext('2d');
            this.charts.timeline = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: Object.keys(timelineData),
                    datasets: [{
                        label: 'Security Events',
                        data: Object.values(timelineData),
                        borderColor: '#2271b1',
                        backgroundColor: 'rgba(34, 113, 177, 0.1)',
                        borderWidth: 3,
                        fill: true,
                        tension: 0.4,
                        pointBackgroundColor: '#2271b1',
                        pointBorderColor: '#fff',
                        pointBorderWidth: 2,
                        pointRadius: 5,
                        pointHoverRadius: 7
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        },
                        tooltip: {
                            mode: 'index',
                            intersect: false
                        }
                    },
                    scales: {
                        x: {
                            grid: {
                                display: false
                            },
                            ticks: {
                                maxRotation: 0
                            }
                        },
                        y: {
                            beginAtZero: true,
                            ticks: {
                                precision: 0
                            },
                            grid: {
                                borderDash: [3, 3]
                            }
                        }
                    },
                    interaction: {
                        intersect: false,
                        mode: 'nearest'
                    }
                }
            });
        }

        initAttackTypesChart() {
            const $chart = $('#attack-types-chart');
            if (!$chart.length) return;

            const attackData = this.getAttackTypesData();
            
            const ctx = $chart[0].getContext('2d');
            this.charts.attackTypes = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: Object.keys(attackData),
                    datasets: [{
                        label: 'Attack Attempts',
                        data: Object.values(attackData),
                        backgroundColor: [
                            '#d63638',
                            '#dba617', 
                            '#2271b1',
                            '#00a32a',
                            '#8c35e0'
                        ],
                        borderColor: '#fff',
                        borderWidth: 1,
                        borderRadius: 4,
                        borderSkipped: false
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        x: {
                            grid: {
                                display: false
                            }
                        },
                        y: {
                            beginAtZero: true,
                            ticks: {
                                precision: 0
                            },
                            grid: {
                                borderDash: [3, 3]
                            }
                        }
                    },
                    indexAxis: 'y' // Horizontal bars
                }
            });
        }

        getSeverityData() {
            // This data would typically come from AJAX
            // For now, using placeholder data
            return {
                critical: 12,
                high: 45,
                medium: 89,
                low: 156
            };
        }

        getTimelineData() {
            // Generate last 7 days data
            const data = {};
            for (let i = 6; i >= 0; i--) {
                const date = new Date();
                date.setDate(date.getDate() - i);
                const dateString = date.toISOString().split('T')[0];
                data[dateString] = Math.floor(Math.random() * 50) + 10;
            }
            return data;
        }

        getAttackTypesData() {
            return {
                'SQL Injection': 23,
                'XSS Attacks': 45,
                'Brute Force': 67,
                'Directory Traversal': 12,
                'File Inclusion': 8
            };
        }

        updateCharts() {
            // Method to refresh all charts with new data
            Object.values(this.charts).forEach(chart => {
                chart.destroy();
            });
            this.charts = {};
            this.init();
        }

        // Export chart as image
        exportChart(chartId, filename = 'chart.png') {
            const chart = this.charts[chartId];
            if (chart) {
                const link = document.createElement('a');
                link.download = filename;
                link.href = chart.toBase64Image();
                link.click();
            }
        }
    }

    // Initialize charts when document is ready
    $(document).ready(() => {
        window.wpFortCharts = new WPFortCharts();
    });

})(jQuery);