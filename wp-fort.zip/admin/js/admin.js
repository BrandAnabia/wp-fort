/**
 * WP Fort Admin JavaScript
 * 
 * @package WP_Fort
 * @since 1.0.0
 */

(function($) {
    'use strict';

    class WPFortAdmin {
        constructor() {
            this.init();
        }

        init() {
            this.bindEvents();
            this.initTabs();
            this.initIPManagement();
            this.initLogs();
        }

        bindEvents() {
            // Toggle switches - remove auto-save for now
            $(document).on('change', '.wp-fort-toggle input', this.handleToggleChange.bind(this));
            
            // Form submissions - FIXED: Proper form submission
            $(document).on('submit', '.wp-fort-settings-form', this.handleFormSubmit.bind(this));
            
            // IP management
            $(document).on('click', '.wp-fort-add-ip', this.addIP.bind(this));
            $(document).on('click', '.wp-fort-remove-ip', this.removeIP.bind(this));
            
            // Logs management
            $(document).on('click', '.wp-fort-clear-logs', this.clearLogs.bind(this));
            $(document).on('click', '.wp-fort-export-logs', this.exportLogs.bind(this));
            $(document).on('click', '.wp-fort-refresh-logs', this.refreshLogs.bind(this));
            
            // Quick actions
            $(document).on('click', '.wp-fort-quick-action', this.handleQuickAction.bind(this));
        }

        initTabs() {
            $('.wp-fort-tab-nav a').on('click', function(e) {
                e.preventDefault();
                
                const target = $(this).attr('href');
                
                // Update active tab
                $('.wp-fort-tab-nav a').removeClass('active');
                $(this).addClass('active');
                
                // Show target content
                $('.wp-fort-tab-content').hide();
                $(target).show();
                
                // Update URL
                history.pushState(null, null, $(this).attr('href'));
            });
            
            // Show current tab based on URL hash
            const currentHash = window.location.hash;
            if (currentHash) {
                $('.wp-fort-tab-nav a[href="' + currentHash + '"]').click();
            } else {
                $('.wp-fort-tab-nav a:first').click();
            }
        }

        initIPManagement() {
            // Auto-focus IP input
            $('.wp-fort-ip-input').focus();
        }

        initLogs() {
            this.loadLogs(1);
        }

        handleToggleChange(e) {
            const $toggle = $(e.target);
            const $form = $toggle.closest('form');
            
            // Remove auto-save for now to prevent conflicts
            // We'll rely on manual save button clicks
        }

        handleFormSubmit(e) {
            e.preventDefault();
            this.saveSettings($(e.target));
        }

        saveSettings($form) {
            const formData = $form.serialize();
            const $submit = $form.find('input[type="submit"], button[type="submit"]');
            const originalText = $submit.val() || $submit.text();
            
            // Show loading state
            $submit.prop('disabled', true);
            if ($submit.is('input')) {
                $submit.val(wp_fort_ajax.loading_text);
            } else {
                $submit.text(wp_fort_ajax.loading_text);
            }
            $submit.addClass('wp-fort-loading');
            
            // Use WordPress settings API submission
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: formData + '&action=wp_fort_save_settings',
                success: (response) => {
                    if (response.success) {
                        this.showNotice('Settings saved successfully!', 'success');
                    } else {
                        this.showNotice('Failed to save settings. Please try again.', 'error');
                    }
                },
                error: (xhr, status, error) => {
                    console.error('Save error:', error);
                    this.showNotice('Error saving settings: ' + error, 'error');
                },
                complete: () => {
                    // Restore button state
                    $submit.prop('disabled', false);
                    if ($submit.is('input')) {
                        $submit.val(originalText);
                    } else {
                        $submit.text(originalText);
                    }
                    $submit.removeClass('wp-fort-loading');
                }
            });
        }

        addIP(e) {
            e.preventDefault();
            
            const $button = $(e.target).is('button') ? $(e.target) : $(e.target).closest('button');
            const $input = $('.wp-fort-ip-input');
            const ip = $input.val().trim();
            
            if (!this.validateIP(ip)) {
                this.showNotice('Please enter a valid IP address.', 'error');
                return;
            }
            
            $button.addClass('wp-fort-loading').prop('disabled', true);
            $button.append('<span class="wp-fort-spinner"></span>');
            
            $.ajax({
                url: wp_fort_ajax.ajaxurl,
                type: 'POST',
                data: {
                    action: 'wp_fort_add_ip',
                    ip: ip,
                    nonce: wp_fort_ajax.nonce
                },
                success: (response) => {
                    if (response.success) {
                        $input.val('');
                        this.refreshIPList();
                        this.showNotice(response.data, 'success');
                    } else {
                        this.showNotice(response.data, 'error');
                    }
                },
                error: () => {
                    this.showNotice(wp_fort_ajax.error_text, 'error');
                },
                complete: () => {
                    $button.removeClass('wp-fort-loading').prop('disabled', false);
                    $button.find('.wp-fort-spinner').remove();
                }
            });
        }

        removeIP(e) {
            e.preventDefault();
            
            const $button = $(e.target).is('button') ? $(e.target) : $(e.target).closest('button');
            const ip = $button.data('ip');
            
            if (!confirm('Are you sure you want to remove this IP address from the whitelist?')) {
                return;
            }
            
            $button.addClass('wp-fort-loading').prop('disabled', true);
            $button.append('<span class="wp-fort-spinner"></span>');
            
            $.ajax({
                url: wp_fort_ajax.ajaxurl,
                type: 'POST',
                data: {
                    action: 'wp_fort_remove_ip',
                    ip: ip,
                    nonce: wp_fort_ajax.nonce
                },
                success: (response) => {
                    if (response.success) {
                        this.refreshIPList();
                        this.showNotice(response.data, 'success');
                    } else {
                        this.showNotice(response.data, 'error');
                    }
                },
                error: () => {
                    this.showNotice(wp_fort_ajax.error_text, 'error');
                },
                complete: () => {
                    $button.removeClass('wp-fort-loading').prop('disabled', false);
                    $button.find('.wp-fort-spinner').remove();
                }
            });
        }

        refreshIPList() {
            // Reload the page to refresh IP list
            window.location.reload();
        }

        loadLogs(page = 1) {
            const $logsContainer = $('.wp-fort-logs-container');
            
            $logsContainer.addClass('wp-fort-loading');
            
            $.ajax({
                url: wp_fort_ajax.ajaxurl,
                type: 'POST',
                data: {
                    action: 'wp_fort_get_logs',
                    page: page,
                    nonce: wp_fort_ajax.nonce
                },
                success: (response) => {
                    if (response.success) {
                        this.displayLogs(response.data.logs, response.data.current_page, response.data.total_pages);
                    } else {
                        this.showNotice('Failed to load security logs.', 'error');
                    }
                },
                error: () => {
                    this.showNotice(wp_fort_ajax.error_text, 'error');
                },
                complete: () => {
                    $logsContainer.removeClass('wp-fort-loading');
                }
            });
        }

        displayLogs(logs, currentPage, totalPages) {
            let html = '';
            
            if (logs.length === 0) {
                html = '<tr><td colspan="9" style="text-align: center; padding: 40px;">No security logs found.</td></tr>';
            } else {
                logs.forEach(log => {
                    html += `
                        <tr>
                            <td>${log.timestamp}</td>
                            <td>${this.formatEventType(log.event_type)}</td>
                            <td><code>${log.ip_address}</code></td>
                            <td>${log.username || '—'}</td>
                            <td>${log.country || 'Unknown'}</td>
                            <td>${log.region || '—'}</td>
                            <td>${log.city || '—'}</td>
                            <td><span class="wp-fort-severity ${log.severity}">${log.severity}</span></td>
                            <td>${log.details || '—'}</td>
                        </tr>
                    `;
                });
            }
            
            $('.wp-fort-logs-table tbody').html(html);
            this.updatePagination(currentPage, totalPages);
        }

        updatePagination(currentPage, totalPages) {
            let paginationHtml = '';
            
            if (totalPages > 1) {
                paginationHtml = '<div class="wp-fort-pagination">';
                
                if (currentPage > 1) {
                    paginationHtml += `<button class="wp-fort-btn wp-fort-btn-secondary" data-page="${currentPage - 1}">Previous</button>`;
                }
                
                paginationHtml += `<span class="wp-fort-page-info">Page ${currentPage} of ${totalPages}</span>`;
                
                if (currentPage < totalPages) {
                    paginationHtml += `<button class="wp-fort-btn wp-fort-btn-secondary" data-page="${currentPage + 1}">Next</button>`;
                }
                
                paginationHtml += '</div>';
            }
            
            $('.wp-fort-logs-pagination').html(paginationHtml);
            
            // Bind pagination events
            $('.wp-fort-pagination button').on('click', (e) => {
                const page = $(e.target).data('page');
                this.loadLogs(page);
            });
        }

        clearLogs(e) {
            e.preventDefault();
            
            if (!confirm('Are you sure you want to clear all security logs? This action cannot be undone.')) {
                return;
            }
            
            const $button = $(e.target).is('button') ? $(e.target) : $(e.target).closest('button');
            $button.addClass('wp-fort-loading').prop('disabled', true);
            $button.append('<span class="wp-fort-spinner"></span>');
            
            $.ajax({
                url: wp_fort_ajax.ajaxurl,
                type: 'POST',
                data: {
                    action: 'wp_fort_clear_logs',
                    nonce: wp_fort_ajax.nonce
                },
                success: (response) => {
                    if (response.success) {
                        this.loadLogs(1);
                        this.showNotice(response.data, 'success');
                    } else {
                        this.showNotice(response.data, 'error');
                    }
                },
                error: () => {
                    this.showNotice(wp_fort_ajax.error_text, 'error');
                },
                complete: () => {
                    $button.removeClass('wp-fort-loading').prop('disabled', false);
                    $button.find('.wp-fort-spinner').remove();
                }
            });
        }

        exportLogs(e) {
            e.preventDefault();
            
            const $button = $(e.target).is('button') ? $(e.target) : $(e.target).closest('button');
            $button.addClass('wp-fort-loading').prop('disabled', true);
            $button.append('<span class="wp-fort-spinner"></span>');
            
            // Trigger download
            window.location.href = wp_fort_ajax.ajaxurl + '?action=wp_fort_export_logs&nonce=' + wp_fort_ajax.nonce;
            
            setTimeout(() => {
                $button.removeClass('wp-fort-loading').prop('disabled', false);
                $button.find('.wp-fort-spinner').remove();
            }, 2000);
        }

        refreshLogs(e) {
            e.preventDefault();
            this.loadLogs(1);
        }

        handleQuickAction(e) {
            e.preventDefault();
            
            const $button = $(e.target).is('button') ? $(e.target) : $(e.target).closest('button');
            const action = $button.data('action');
            
            $button.addClass('wp-fort-loading').prop('disabled', true);
            $button.append('<span class="wp-fort-spinner"></span>');
            
            // Handle different quick actions
            switch (action) {
                case 'test_login_url':
                    this.testLoginURL();
                    break;
                case 'scan_security':
                    this.scanSecurity();
                    break;
                case 'backup_settings':
                    this.backupSettings();
                    break;
            }
            
            setTimeout(() => {
                $button.removeClass('wp-fort-loading').prop('disabled', false);
                $button.find('.wp-fort-spinner').remove();
            }, 2000);
        }

        testLoginURL() {
            const loginURL = $('.wp-fort-custom-login-url').val();
            if (loginURL) {
                const fullURL = window.location.origin + '/' + loginURL;
                window.open(fullURL, '_blank');
            }
        }

        scanSecurity() {
            // Placeholder for security scan
            this.showNotice('Security scan completed. No issues found.', 'success');
        }

        backupSettings() {
            // Placeholder for settings backup
            this.showNotice('Settings backup created successfully.', 'success');
        }

        validateIP(ip) {
            const ipPattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
            return ipPattern.test(ip);
        }

        formatEventType(eventType) {
            const eventMap = {
                'login_success': 'Login Success',
                'login_failed': 'Login Failed',
                'ip_blocked': 'IP Blocked',
                'brute_force_detected': 'Brute Force',
                'suspicious_request': 'Suspicious Request',
                'file_change_detected': 'File Change'
            };
            
            return eventMap[eventType] || eventType.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
        }

        showNotice(message, type = 'info') {
            // Remove any existing notices first
            $('.wp-fort-notice').remove();
            
            const noticeClass = type === 'error' ? 'notice-error' : 'notice-success';
            const noticeHTML = `
                <div class="notice ${noticeClass} wp-fort-notice is-dismissible">
                    <p>${message}</p>
                    <button type="button" class="notice-dismiss">
                        <span class="screen-reader-text">Dismiss this notice.</span>
                    </button>
                </div>
            `;
            
            $('.wp-fort-admin').prepend(noticeHTML);
            
            // Auto-remove after 5 seconds
            setTimeout(() => {
                $('.wp-fort-notice').fadeOut(300, function() {
                    $(this).remove();
                });
            }, 5000);
            
            // Bind dismiss button
            $('.notice-dismiss').on('click', function() {
                $(this).closest('.wp-fort-notice').fadeOut(300, function() {
                    $(this).remove();
                });
            });
        }
    }

    // Initialize when document is ready
    $(document).ready(() => {
        window.wpFortAdmin = new WPFortAdmin();
    });

})(jQuery);