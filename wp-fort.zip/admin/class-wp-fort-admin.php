<?php
/**
 * WP Fort Admin Dashboard Class
 * 
 * @package WP_Fort
 * @since 1.0.0
 */

class WP_Fort_Admin {
    
    private $core;
    private $page_hook;
    
    public function __construct() {
        $this->core = WP_Fort_Core::get_instance();
        $this->init_hooks();
    }
    
    private function init_hooks() {
        add_action('admin_menu', array($this, 'admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('wp_ajax_wp_fort_get_logs', array($this, 'ajax_get_security_logs'));
        add_action('wp_ajax_wp_fort_clear_logs', array($this, 'ajax_clear_security_logs'));
        add_action('wp_ajax_wp_fort_export_logs', array($this, 'ajax_export_security_logs'));
        add_action('wp_ajax_wp_fort_add_ip', array($this, 'ajax_add_ip'));
        add_action('wp_ajax_wp_fort_remove_ip', array($this, 'ajax_remove_ip'));
        
        // Dashboard widgets
        add_action('wp_dashboard_setup', array($this, 'add_dashboard_widgets'));
        
        // Admin notices
        add_action('admin_notices', array($this, 'admin_notices'));
    }
    
    /**
     * Add admin menu
     */
    public function admin_menu() {
        $this->page_hook = add_menu_page(
            __('WP Fort Security', 'wp-fort'),
            __('WP Fort', 'wp-fort'),
            'manage_options',
            'wp-fort',
            array($this, 'admin_dashboard'),
            'dashicons-shield',
            100
        );
        
        // Submenus
        add_submenu_page(
            'wp-fort',
            __('Dashboard - WP Fort', 'wp-fort'),
            __('Dashboard', 'wp-fort'),
            'manage_options',
            'wp-fort',
            array($this, 'admin_dashboard')
        );
        
        add_submenu_page(
            'wp-fort',
            __('Login Protection - WP Fort', 'wp-fort'),
            __('Login Protection', 'wp-fort'),
            'manage_options',
            'wp-fort-login-protection',
            array($this, 'login_protection_page')
        );
        
        add_submenu_page(
            'wp-fort',
            __('IP Restrictions - WP Fort', 'wp-fort'),
            __('IP Restrictions', 'wp-fort'),
            'manage_options',
            'wp-fort-ip-restrictions',
            array($this, 'ip_restrictions_page')
        );
        
        add_submenu_page(
            'wp-fort',
            __('Security Logs - WP Fort', 'wp-fort'),
            __('Security Logs', 'wp-fort'),
            'manage_options',
            'wp-fort-security-logs',
            array($this, 'security_logs_page')
        );
        
        add_submenu_page(
            'wp-fort',
            __('Firewall - WP Fort', 'wp-fort'),
            __('Firewall', 'wp-fort'),
            'manage_options',
            'wp-fort-firewall',
            array($this, 'firewall_page')
        );
        
        add_submenu_page(
            'wp-fort',
            __('Cloudflare - WP Fort', 'wp-fort'),
            __('Cloudflare', 'wp-fort'),
            'manage_options',
            'wp-fort-cloudflare',
            array($this, 'cloudflare_page')
        );
        
        add_submenu_page(
            'wp-fort',
            __('Settings - WP Fort', 'wp-fort'),
            __('Settings', 'wp-fort'),
            'manage_options',
            'wp-fort-settings',
            array($this, 'settings_page')
        );
    }
    
    /**
     * Enqueue admin scripts and styles
     */
    public function enqueue_admin_scripts($hook) {
        if (strpos($hook, 'wp-fort') === false) {
            return;
        }
        
        wp_enqueue_style(
            'wp-fort-admin',
            WP_FORT_PLUGIN_URL . 'admin/css/admin.css',
            array(),
            WP_FORT_VERSION
        );
        
        wp_enqueue_script(
            'wp-fort-admin',
            WP_FORT_PLUGIN_URL . 'admin/js/admin.js',
            array('jquery', 'wp-util'),
            WP_FORT_VERSION,
            true
        );
        
        // Add charts for dashboard
        if ($hook === $this->page_hook) {
            wp_enqueue_script(
                'wp-fort-charts',
                WP_FORT_PLUGIN_URL . 'admin/js/charts.js',
                array('wp-fort-admin'),
                WP_FORT_VERSION,
                true
            );
        }
        
        // Localize script for AJAX
        wp_localize_script('wp-fort-admin', 'wp_fort_ajax', array(
            'nonce' => wp_create_nonce('wp_fort_ajax_nonce'),
            'ajaxurl' => admin_url('admin-ajax.php'),
            'loading_text' => __('Loading...', 'wp-fort'),
            'error_text' => __('Error occurred. Please try again.', 'wp-fort')
        ));
    }
    
    /**
     * Register settings
     */
    public function register_settings() {
        register_setting('wp_fort_settings', 'wp_fort_settings', array($this, 'sanitize_settings'));
    }
    
    /**
     * Sanitize settings
     */
    public function sanitize_settings($input) {
        $output = array();
        
        // Login Protection
        $output['login_protection_enabled'] = isset($input['login_protection_enabled']);
        $output['custom_login_slug'] = sanitize_title($input['custom_login_slug'] ?? 'secure-admin');
        $output['block_wp_login'] = isset($input['block_wp_login']);
        
        // IP Restrictions
        $output['ip_restriction_enabled'] = isset($input['ip_restriction_enabled']);
        $output['allowed_ips'] = $this->sanitize_ip_list($input['allowed_ips'] ?? array());
        
        // Security Logging
        $output['logging_enabled'] = isset($input['logging_enabled']);
        $output['log_retention_days'] = absint($input['log_retention_days'] ?? 30);
        $output['log_failed_logins'] = isset($input['log_failed_logins']);
        $output['log_successful_logins'] = isset($input['log_successful_logins']);
        
        // Firewall
        $output['firewall_enabled'] = isset($input['firewall_enabled']);
        $output['block_suspicious_requests'] = isset($input['block_suspicious_requests']);
        $output['prevent_php_execution'] = isset($input['prevent_php_execution']);
        
        // Brute Force Protection
        $output['brute_force_protection'] = isset($input['brute_force_protection']);
        $output['max_login_attempts'] = absint($input['max_login_attempts'] ?? 5);
        $output['lockout_duration'] = absint($input['lockout_duration'] ?? 30);
        
        // Cloudflare
        $output['cloudflare_enabled'] = isset($input['cloudflare_enabled']);
        $output['cloudflare_api_key'] = sanitize_text_field($input['cloudflare_api_key'] ?? '');
        $output['cloudflare_email'] = sanitize_email($input['cloudflare_email'] ?? '');
        $output['cloudflare_zone_id'] = sanitize_text_field($input['cloudflare_zone_id'] ?? '');
        
        // General Settings
        $output['disable_xmlrpc'] = isset($input['disable_xmlrpc']);
        $output['hide_wp_version'] = isset($input['hide_wp_version']);
        $output['disable_file_edit'] = isset($input['disable_file_edit']);
        
        return $output;
    }
    
    /**
     * Sanitize IP list
     */
    private function sanitize_ip_list($ips) {
        if (!is_array($ips)) {
            return array();
        }
        
        $sanitized_ips = array();
        foreach ($ips as $ip) {
            $clean_ip = sanitize_text_field($ip);
            if (filter_var($clean_ip, FILTER_VALIDATE_IP)) {
                $sanitized_ips[] = $clean_ip;
            }
        }
        
        return array_unique($sanitized_ips);
    }
    
    /**
     * Main dashboard page
     */
    public function admin_dashboard() {
        $options = $this->core->get_options();
        $stats = $this->get_security_stats();
        
        include WP_FORT_PLUGIN_PATH . 'admin/partials/dashboard.php';
    }
    
    /**
     * Login protection page
     */
    public function login_protection_page() {
        $options = $this->core->get_options();
        
        include WP_FORT_PLUGIN_PATH . 'admin/partials/login-security.php';
    }
    
    /**
     * IP restrictions page
     */
    public function ip_restrictions_page() {
        $options = $this->core->get_options();
        $current_ip = WP_Fort_Core::get_client_ip();
        
        include WP_FORT_PLUGIN_PATH . 'admin/partials/ip-restrictions.php';
    }
    
    /**
     * Security logs page
     */
    public function security_logs_page() {
        $options = $this->core->get_options();
        
        include WP_FORT_PLUGIN_PATH . 'admin/partials/security-logs.php';
    }
    
    /**
     * Firewall page
     */
    public function firewall_page() {
        $options = $this->core->get_options();
        
        include WP_FORT_PLUGIN_PATH . 'admin/partials/firewall.php';
    }
    
    /**
     * Cloudflare page
     */
    public function cloudflare_page() {
        $options = $this->core->get_options();
        
        include WP_FORT_PLUGIN_PATH . 'admin/partials/cloudflare.php';
    }
    
    /**
     * Settings page
     */
    public function settings_page() {
        $options = $this->core->get_options();
        
        include WP_FORT_PLUGIN_PATH . 'admin/partials/settings.php';
    }
    
    /**
     * Get security statistics
     */
    private function get_security_stats() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'wp_fort_security_logs';
        
        $stats = array(
            'total_events' => 0,
            'failed_logins' => 0,
            'blocked_ips' => 0,
            'suspicious_requests' => 0,
            'today_events' => 0,
            'events_by_severity' => array(
                'critical' => 0,
                'high' => 0,
                'medium' => 0,
                'low' => 0
            ),
            'recent_events' => array()
        );
        
        // Total events
        $stats['total_events'] = $wpdb->get_var(
            "SELECT COUNT(*) FROM $table_name"
        );
        
        // Failed logins
        $stats['failed_logins'] = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM $table_name WHERE event_type = %s",
                'login_failed'
            )
        );
        
        // Blocked IPs
        $stats['blocked_ips'] = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM $table_name WHERE event_type = %s",
                'ip_blocked'
            )
        );
        
        // Suspicious requests
        $stats['suspicious_requests'] = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM $table_name WHERE event_type = %s",
                'suspicious_request'
            )
        );
        
        // Today's events
        $stats['today_events'] = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM $table_name WHERE DATE(timestamp) = %s",
                current_time('mysql')
            )
        );
        
        // Events by severity
        $severity_counts = $wpdb->get_results(
            "SELECT severity, COUNT(*) as count FROM $table_name GROUP BY severity",
            ARRAY_A
        );
        
        foreach ($severity_counts as $severity) {
            $stats['events_by_severity'][$severity['severity']] = $severity['count'];
        }
        
        // Recent events (last 10)
        $stats['recent_events'] = $wpdb->get_results(
            "SELECT * FROM $table_name ORDER BY timestamp DESC LIMIT 10",
            ARRAY_A
        );
        
        return $stats;
    }
    
    /**
     * AJAX: Get security logs
     */
    public function ajax_get_security_logs() {
        check_ajax_referer('wp_fort_ajax_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(-1);
        }
        
        global $wpdb;
        
        $page = absint($_POST['page'] ?? 1);
        $per_page = 20;
        $offset = ($page - 1) * $per_page;
        
        $logs = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}wp_fort_security_logs 
                 ORDER BY timestamp DESC 
                 LIMIT %d OFFSET %d",
                $per_page,
                $offset
            ),
            ARRAY_A
        );
        
        $total_logs = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}wp_fort_security_logs");
        
        wp_send_json_success(array(
            'logs' => $logs,
            'total_pages' => ceil($total_logs / $per_page),
            'current_page' => $page
        ));
    }
    
    /**
     * AJAX: Clear security logs
     */
    public function ajax_clear_security_logs() {
        check_ajax_referer('wp_fort_ajax_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(-1);
        }
        
        global $wpdb;
        
        $result = $wpdb->query("TRUNCATE TABLE {$wpdb->prefix}wp_fort_security_logs");
        
        if ($result !== false) {
            wp_send_json_success(__('Security logs cleared successfully.', 'wp-fort'));
        } else {
            wp_send_json_error(__('Failed to clear security logs.', 'wp-fort'));
        }
    }
    
    /**
     * AJAX: Export security logs
     */
    public function ajax_export_security_logs() {
        check_ajax_referer('wp_fort_ajax_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(-1);
        }
        
        global $wpdb;
        
        $logs = $wpdb->get_results(
            "SELECT * FROM {$wpdb->prefix}wp_fort_security_logs ORDER BY timestamp DESC",
            ARRAY_A
        );
        
        // Generate CSV
        $filename = 'wp-fort-security-logs-' . date('Y-m-d-H-i-s') . '.csv';
        
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        
        $output = fopen('php://output', 'w');
        
        // Headers
        fputcsv($output, array(
            'Timestamp',
            'Event Type',
            'IP Address',
            'Username',
            'Country',
            'Region',
            'City',
            'Severity',
            'Details'
        ));
        
        // Data
        foreach ($logs as $log) {
            fputcsv($output, array(
                $log['timestamp'],
                $log['event_type'],
                $log['ip_address'],
                $log['username'],
                $log['country'],
                $log['region'],
                $log['city'],
                $log['severity'],
                $log['details']
            ));
        }
        
        fclose($output);
        exit;
    }
    
    /**
     * AJAX: Add IP to whitelist
     */
    public function ajax_add_ip() {
        check_ajax_referer('wp_fort_ajax_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(-1);
        }
        
        $ip = sanitize_text_field($_POST['ip'] ?? '');
        
        if (!filter_var($ip, FILTER_VALIDATE_IP)) {
            wp_send_json_error(__('Invalid IP address.', 'wp-fort'));
        }
        
        $options = $this->core->get_options();
        
        if (!in_array($ip, $options['allowed_ips'])) {
            $options['allowed_ips'][] = $ip;
            $this->core->update_options($options);
            
            wp_send_json_success(__('IP address added to whitelist.', 'wp-fort'));
        } else {
            wp_send_json_error(__('IP address already in whitelist.', 'wp-fort'));
        }
    }
    
    /**
     * AJAX: Remove IP from whitelist
     */
    public function ajax_remove_ip() {
        check_ajax_referer('wp_fort_ajax_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(-1);
        }
        
        $ip = sanitize_text_field($_POST['ip'] ?? '');
        
        $options = $this->core->get_options();
        
        if (($key = array_search($ip, $options['allowed_ips'])) !== false) {
            unset($options['allowed_ips'][$key]);
            $options['allowed_ips'] = array_values($options['allowed_ips']);
            $this->core->update_options($options);
            
            wp_send_json_success(__('IP address removed from whitelist.', 'wp-fort'));
        } else {
            wp_send_json_error(__('IP address not found in whitelist.', 'wp-fort'));
        }
    }
    
    /**
     * Add dashboard widgets
     */
    public function add_dashboard_widgets() {
        wp_add_dashboard_widget(
            'wp_fort_security_widget',
            __('WP Fort Security Overview', 'wp-fort'),
            array($this, 'dashboard_widget_content')
        );
    }
    
    /**
     * Dashboard widget content
     */
    public function dashboard_widget_content() {
        $stats = $this->get_security_stats();
        $options = $this->core->get_options();
        
        echo '<div class="wp-fort-dashboard-widget">';
        echo '<div class="security-status ' . ($stats['today_events'] > 10 ? 'warning' : 'good') . '">';
        echo '<p><strong>' . __('Today\'s Events:', 'wp-fort') . '</strong> ' . $stats['today_events'] . '</p>';
        echo '</div>';
        
        echo '<div class="security-stats">';
        echo '<p><strong>' . __('Failed Logins:', 'wp-fort') . '</strong> ' . $stats['failed_logins'] . '</p>';
        echo '<p><strong>' . __('Blocked IPs:', 'wp-fort') . '</strong> ' . $stats['blocked_ips'] . '</p>';
        echo '</div>';
        
        echo '<div class="security-actions">';
        echo '<a href="' . admin_url('admin.php?page=wp-fort-security-logs') . '" class="button button-primary">' . __('View Security Logs', 'wp-fort') . '</a>';
        echo '</div>';
        echo '</div>';
    }
    
    /**
     * Admin notices
     */
    public function admin_notices() {
        $options = $this->core->get_options();
        
        // Notice for first-time setup
        if ($options['login_protection_enabled'] && empty($options['custom_login_slug'])) {
            echo '<div class="notice notice-warning">';
            echo '<p>' . __('WP Fort: Please configure your custom login URL in the security settings.', 'wp-fort') . '</p>';
            echo '</div>';
        }
        
        // Notice if IP restriction is enabled but no IPs are whitelisted
        if ($options['ip_restriction_enabled'] && empty($options['allowed_ips'])) {
            echo '<div class="notice notice-error">';
            echo '<p>' . __('WP Fort: IP restriction is enabled but no IP addresses are whitelisted. You may lock yourself out!', 'wp-fort') . '</p>';
            echo '</div>';
        }
    }
}