<?php
/**
 * WP Fort Firewall Settings
 * 
 * @package WP_Fort
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap wp-fort-admin">
    <div class="wp-fort-header">
        <h1><?php _e('Firewall Settings', 'wp-fort'); ?></h1>
        <p><?php _e('Protect your website from malicious requests and attacks with advanced firewall rules.', 'wp-fort'); ?></p>
    </div>

    <form method="post" action="options.php" class="wp-fort-settings-form wp-fort-auto-save">
        <?php settings_fields('wp_fort_settings'); ?>
        
        <div class="wp-fort-form-section">
            <h3><?php _e('Firewall Protection', 'wp-fort'); ?></h3>
            
            <div class="wp-fort-form-row">
                <label>
                    <input type="checkbox" name="wp_fort_settings[firewall_enabled]" value="1" 
                        <?php checked($options['firewall_enabled'], 1); ?> 
                        class="wp-fort-toggle">
                    <?php _e('Enable Firewall Protection', 'wp-fort'); ?>
                </label>
                <p class="wp-fort-form-help">
                    <?php _e('Block malicious requests and protect against common web attacks.', 'wp-fort'); ?>
                </p>
            </div>

            <div class="wp-fort-form-row">
                <label>
                    <input type="checkbox" name="wp_fort_settings[block_suspicious_requests]" value="1" 
                        <?php checked($options['block_suspicious_requests'], 1); ?>>
                    <?php _e('Block Suspicious Requests', 'wp-fort'); ?>
                </label>
                <p class="wp-fort-form-help">
                    <?php _e('Automatically block requests with suspicious patterns (SQL injection, XSS attempts, etc.).', 'wp-fort'); ?>
                </p>
            </div>

            <div class="wp-fort-form-row">
                <label>
                    <input type="checkbox" name="wp_fort_settings[prevent_php_execution]" value="1" 
                        <?php checked($options['prevent_php_execution'], 1); ?>>
                    <?php _e('Prevent PHP Execution in Uploads', 'wp-fort'); ?>
                </label>
                <p class="wp-fort-form-help">
                    <?php _e('Block PHP file execution in the uploads directory to prevent malware attacks.', 'wp-fort'); ?>
                </p>
            </div>
        </div>

        <div class="wp-fort-form-section">
            <h3><?php _e('Advanced Firewall Rules', 'wp-fort'); ?></h3>
            
            <div class="wp-fort-form-row">
                <label for="blocked_user_agents"><?php _e('Blocked User Agents', 'wp-fort'); ?></label>
                <textarea id="blocked_user_agents" name="wp_fort_settings[blocked_user_agents]" 
                    rows="5" class="large-text" placeholder="nmap&#10;sqlmap&#10;wpscan&#10;acunetix"
                    style="font-family: monospace;"><?php echo esc_textarea($options['blocked_user_agents'] ?? ''); ?></textarea>
                <p class="wp-fort-form-help">
                    <?php _e('List of user agents to block (one per line). Common security scanners are blocked by default.', 'wp-fort'); ?>
                </p>
            </div>

            <div class="wp-fort-form-row">
                <label for="blocked_ips"><?php _e('Permanently Blocked IPs', 'wp-fort'); ?></label>
                <textarea id="blocked_ips" name="wp_fort_settings[blocked_ips]" 
                    rows="5" class="large-text" placeholder="123.456.789.0&#10;192.168.1.100"
                    style="font-family: monospace;"><?php echo esc_textarea($options['blocked_ips'] ?? ''); ?></textarea>
                <p class="wp-fort-form-help">
                    <?php _e('IP addresses to permanently block (one per line).', 'wp-fort'); ?>
                </p>
            </div>
        </div>

        <div class="wp-fort-form-row">
            <?php submit_button(__('Save Settings', 'wp-fort'), 'primary', 'submit'); ?>
        </div>
    </form>

    <div class="wp-fort-form-section">
        <h3><?php _e('Firewall Statistics', 'wp-fort'); ?></h3>
        
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 20px;">
            <div style="text-align: center; padding: 20px; background: #f6f7f7; border-radius: 6px;">
                <div style="font-size: 24px; font-weight: bold; color: #2271b1;">0</div>
                <div><?php _e('Requests Blocked Today', 'wp-fort'); ?></div>
            </div>
            <div style="text-align: center; padding: 20px; background: #f6f7f7; border-radius: 6px;">
                <div style="font-size: 24px; font-weight: bold; color: #2271b1;">0</div>
                <div><?php _e('Malicious IPs Blocked', 'wp-fort'); ?></div>
            </div>
            <div style="text-align: center; padding: 20px; background: #f6f7f7; border-radius: 6px;">
                <div style="font-size: 24px; font-weight: bold; color: #2271b1;">0</div>
                <div><?php _e('SQL Injection Attempts', 'wp-fort'); ?></div>
            </div>
            <div style="text-align: center; padding: 20px; background: #f6f7f7; border-radius: 6px;">
                <div style="font-size: 24px; font-weight: bold; color: #2271b1;">0</div>
                <div><?php _e('XSS Attack Attempts', 'wp-fort'); ?></div>
            </div>
        </div>
    </div>

    <div class="wp-fort-form-section">
        <h3><?php _e('Common Attack Patterns Blocked', 'wp-fort'); ?></h3>
        
        <ul style="list-style: disc; padding-left: 20px;">
            <li><strong><?php _e('SQL Injection:', 'wp-fort'); ?></strong> <?php _e('UNION SELECT, DROP TABLE, INSERT INTO', 'wp-fort'); ?></li>
            <li><strong><?php _e('XSS Attacks:', 'wp-fort'); ?></strong> <?php _e('script tags, javascript protocols, event handlers', 'wp-fort'); ?></li>
            <li><strong><?php _e('Directory Traversal:', 'wp-fort'); ?></strong> <?php _e('../ sequences, absolute paths', 'wp-fort'); ?></li>
            <li><strong><?php _e('File Inclusion:', 'wp-fort'); ?></strong> <?php _e('include(), require(), file_get_contents()', 'wp-fort'); ?></li>
            <li><strong><?php _e('Command Injection:', 'wp-fort'); ?></strong> <?php _e('system(), exec(), shell_exec()', 'wp-fort'); ?></li>
        </ul>
        
        <p style="margin-top: 15px; padding: 10px; background: #f0f6fc; border-radius: 4px;">
            <?php _e('The firewall automatically detects and blocks these patterns without requiring manual configuration.', 'wp-fort'); ?>
        </p>
    </div>
</div>