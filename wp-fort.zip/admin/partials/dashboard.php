<?php
/**
 * WP Fort Dashboard Template
 * 
 * @package WP_Fort
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap wp-fort-admin">
    <div class="wp-fort-header">
        <h1><?php _e('WP Fort Security Dashboard', 'wp-fort'); ?></h1>
        <p><?php _e('Comprehensive security protection for your WordPress website.', 'wp-fort'); ?></p>
    </div>

    <!-- Stats Grid -->
    <div class="wp-fort-stats-grid">
        <div class="wp-fort-stat-card">
            <span class="wp-fort-stat-number"><?php echo esc_html($stats['total_events']); ?></span>
            <span class="wp-fort-stat-label"><?php _e('Total Security Events', 'wp-fort'); ?></span>
        </div>
        
        <div class="wp-fort-stat-card critical">
            <span class="wp-fort-stat-number"><?php echo esc_html($stats['failed_logins']); ?></span>
            <span class="wp-fort-stat-label"><?php _e('Failed Logins', 'wp-fort'); ?></span>
        </div>
        
        <div class="wp-fort-stat-card high">
            <span class="wp-fort-stat-number"><?php echo esc_html($stats['blocked_ips']); ?></span>
            <span class="wp-fort-stat-label"><?php _e('Blocked IPs', 'wp-fort'); ?></span>
        </div>
        
        <div class="wp-fort-stat-card medium">
            <span class="wp-fort-stat-number"><?php echo esc_html($stats['today_events']); ?></span>
            <span class="wp-fort-stat-label"><?php _e("Today's Events", 'wp-fort'); ?></span>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="wp-fort-form-section">
        <h3><?php _e('Quick Actions', 'wp-fort'); ?></h3>
        <div style="display: flex; gap: 10px; flex-wrap: wrap;">
            <button class="wp-fort-btn wp-fort-quick-action" data-action="test_login_url">
                <?php _e('Test Login URL', 'wp-fort'); ?>
            </button>
            <button class="wp-fort-btn wp-fort-btn-secondary wp-fort-quick-action" data-action="scan_security">
                <?php _e('Security Scan', 'wp-fort'); ?>
            </button>
            <button class="wp-fort-btn wp-fort-btn-success wp-fort-quick-action" data-action="backup_settings">
                <?php _e('Backup Settings', 'wp-fort'); ?>
            </button>
        </div>
    </div>

    <!-- Tabs Navigation -->
    <div class="wp-fort-tabs">
        <ul class="wp-fort-tab-nav">
            <li><a href="#overview" class="active"><?php _e('Overview', 'wp-fort'); ?></a></li>
            <li><a href="#recent-events"><?php _e('Recent Events', 'wp-fort'); ?></a></li>
            <li><a href="#security-status"><?php _e('Security Status', 'wp-fort'); ?></a></li>
        </ul>
    </div>

    <!-- Tab Contents -->
    <div id="overview" class="wp-fort-tab-content">
        <h3><?php _e('Security Overview', 'wp-fort'); ?></h3>
        
        <div class="wp-fort-chart-container">
            <h4><?php _e('Events by Severity', 'wp-fort'); ?></h4>
            <div class="wp-fort-chart" id="severity-chart">
                <!-- Chart will be loaded via JavaScript -->
                <p style="text-align: center; padding: 60px 0;"><?php _e('Chart loading...', 'wp-fort'); ?></p>
            </div>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
            <div class="wp-fort-form-section">
                <h4><?php _e('Security Features Status', 'wp-fort'); ?></h4>
                <ul style="list-style: none; padding: 0; margin: 0;">
                    <li style="padding: 8px 0; border-bottom: 1px solid #f0f0f1;">
                        <strong><?php _e('Login Protection:', 'wp-fort'); ?></strong>
                        <span style="color: <?php echo $options['login_protection_enabled'] ? '#00a32a' : '#d63638'; ?>;">
                            <?php echo $options['login_protection_enabled'] ? __('Enabled', 'wp-fort') : __('Disabled', 'wp-fort'); ?>
                        </span>
                    </li>
                    <li style="padding: 8px 0; border-bottom: 1px solid #f0f0f1;">
                        <strong><?php _e('IP Restrictions:', 'wp-fort'); ?></strong>
                        <span style="color: <?php echo $options['ip_restriction_enabled'] ? '#00a32a' : '#d63638'; ?>;">
                            <?php echo $options['ip_restriction_enabled'] ? __('Enabled', 'wp-fort') : __('Disabled', 'wp-fort'); ?>
                        </span>
                    </li>
                    <li style="padding: 8px 0; border-bottom: 1px solid #f0f0f1;">
                        <strong><?php _e('Firewall:', 'wp-fort'); ?></strong>
                        <span style="color: <?php echo $options['firewall_enabled'] ? '#00a32a' : '#d63638'; ?>;">
                            <?php echo $options['firewall_enabled'] ? __('Enabled', 'wp-fort') : __('Disabled', 'wp-fort'); ?>
                        </span>
                    </li>
                    <li style="padding: 8px 0;">
                        <strong><?php _e('Brute Force Protection:', 'wp-fort'); ?></strong>
                        <span style="color: <?php echo $options['brute_force_protection'] ? '#00a32a' : '#d63638'; ?>;">
                            <?php echo $options['brute_force_protection'] ? __('Enabled', 'wp-fort') : __('Disabled', 'wp-fort'); ?>
                        </span>
                    </li>
                </ul>
            </div>

            <div class="wp-fort-form-section">
                <h4><?php _e('System Information', 'wp-fort'); ?></h4>
                <ul style="list-style: none; padding: 0; margin: 0;">
                    <li style="padding: 8px 0; border-bottom: 1px solid #f0f0f1;">
                        <strong><?php _e('WordPress Version:', 'wp-fort'); ?></strong>
                        <?php echo esc_html(get_bloginfo('version')); ?>
                    </li>
                    <li style="padding: 8px 0; border-bottom: 1px solid #f0f0f1;">
                        <strong><?php _e('PHP Version:', 'wp-fort'); ?></strong>
                        <?php echo esc_html(phpversion()); ?>
                    </li>
                    <li style="padding: 8px 0; border-bottom: 1px solid #f0f0f1;">
                        <strong><?php _e('Your IP Address:', 'wp-fort'); ?></strong>
                        <code><?php echo esc_html(WP_Fort_Core::get_client_ip()); ?></code>
                    </li>
                    <li style="padding: 8px 0;">
                        <strong><?php _e('Custom Login URL:', 'wp-fort'); ?></strong>
                        <?php if ($options['login_protection_enabled'] && !empty($options['custom_login_slug'])): ?>
                            <code><?php echo esc_url(home_url($options['custom_login_slug'])); ?></code>
                        <?php else: ?>
                            <span style="color: #d63638;"><?php _e('Not configured', 'wp-fort'); ?></span>
                        <?php endif; ?>
                    </li>
                </ul>
            </div>
        </div>
    </div>

    <div id="recent-events" class="wp-fort-tab-content" style="display: none;">
        <h3><?php _e('Recent Security Events', 'wp-fort'); ?></h3>
        
        <div class="wp-fort-logs-container">
            <table class="wp-fort-logs-table">
                <thead>
                    <tr>
                        <th><?php _e('Timestamp', 'wp-fort'); ?></th>
                        <th><?php _e('Event Type', 'wp-fort'); ?></th>
                        <th><?php _e('IP Address', 'wp-fort'); ?></th>
                        <th><?php _e('Username', 'wp-fort'); ?></th>
                        <th><?php _e('Country', 'wp-fort'); ?></th>
                        <th><?php _e('Region', 'wp-fort'); ?></th>
                        <th><?php _e('City', 'wp-fort'); ?></th>
                        <th><?php _e('Severity', 'wp-fort'); ?></th>
                        <th><?php _e('Details', 'wp-fort'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($stats['recent_events'])): ?>
                        <tr>
                            <td colspan="9" style="text-align: center; padding: 40px;">
                                <?php _e('No security events recorded yet.', 'wp-fort'); ?>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($stats['recent_events'] as $event): ?>
                            <tr>
                                <td><?php echo esc_html($event['timestamp']); ?></td>
                                <td><?php echo esc_html($event['event_type']); ?></td>
                                <td><code><?php echo esc_html($event['ip_address']); ?></code></td>
                                <td><?php echo esc_html($event['username'] ?: '—'); ?></td>
                                <td><?php echo esc_html($event['country'] ?: 'Unknown'); ?></td>
                                <td><?php echo esc_html($event['region'] ?: '—'); ?></td>
                                <td><?php echo esc_html($event['city'] ?: '—'); ?></td>
                                <td>
                                    <span class="wp-fort-severity <?php echo esc_attr($event['severity']); ?>">
                                        <?php echo esc_html($event['severity']); ?>
                                    </span>
                                </td>
                                <td><?php echo esc_html($event['details'] ?: '—'); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <div style="margin-top: 20px; text-align: center;">
            <a href="<?php echo admin_url('admin.php?page=wp-fort-security-logs'); ?>" class="wp-fort-btn">
                <?php _e('View All Security Logs', 'wp-fort'); ?>
            </a>
        </div>
    </div>

    <div id="security-status" class="wp-fort-tab-content" style="display: none;">
        <h3><?php _e('Security Status Check', 'wp-fort'); ?></h3>
        
        <div class="wp-fort-form-section">
            <h4><?php _e('Security Recommendations', 'wp-fort'); ?></h4>
            
            <?php
            $recommendations = array();
            
            if (!$options['login_protection_enabled']) {
                $recommendations[] = __('Enable login protection to hide wp-login.php', 'wp-fort');
            }
            
            if ($options['ip_restriction_enabled'] && empty($options['allowed_ips'])) {
                $recommendations[] = __('Add IP addresses to whitelist when IP restriction is enabled', 'wp-fort');
            }
            
            if (!$options['disable_xmlrpc']) {
                $recommendations[] = __('Disable XML-RPC to prevent brute force attacks', 'wp-fort');
            }
            
            if (empty($recommendations)): ?>
                <div style="background: #edfaef; padding: 15px; border-radius: 4px; border-left: 4px solid #00a32a;">
                    <p style="margin: 0; color: #00a32a;">
                        <strong><?php _e('Excellent!', 'wp-fort'); ?></strong>
                        <?php _e('All security recommendations are implemented.', 'wp-fort'); ?>
                    </p>
                </div>
            <?php else: ?>
                <ul style="list-style: disc; padding-left: 20px;">
                    <?php foreach ($recommendations as $recommendation): ?>
                        <li style="margin-bottom: 8px;"><?php echo esc_html($recommendation); ?></li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </div>
        
        <div class="wp-fort-form-section">
            <h4><?php _e('Security Health Check', 'wp-fort'); ?></h4>
            
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px;">
                <div style="text-align: center; padding: 20px; background: #f6f7f7; border-radius: 6px;">
                    <div style="font-size: 24px; font-weight: bold; color: #00a32a;">✓</div>
                    <div><?php _e('SSL Certificate', 'wp-fort'); ?></div>
                    <div style="font-size: 12px; color: #646970;">
                        <?php echo is_ssl() ? __('Active', 'wp-fort') : __('Not Active', 'wp-fort'); ?>
                    </div>
                </div>
                
                <div style="text-align: center; padding: 20px; background: #f6f7f7; border-radius: 6px;">
                    <div style="font-size: 24px; font-weight: bold; color: #00a32a;">✓</div>
                    <div><?php _e('File Permissions', 'wp-fort'); ?></div>
                    <div style="font-size: 12px; color: #646970;"><?php _e('Checking...', 'wp-fort'); ?></div>
                </div>
                
                <div style="text-align: center; padding: 20px; background: #f6f7f7; border-radius: 6px;">
                    <div style="font-size: 24px; font-weight: bold; color: #00a32a;">✓</div>
                    <div><?php _e('Database Security', 'wp-fort'); ?></div>
                    <div style="font-size: 12px; color: #646970;"><?php _e('Secure', 'wp-fort'); ?></div>
                </div>
                
                <div style="text-align: center; padding: 20px; background: #f6f7f7; border-radius: 6px;">
                    <div style="font-size: 24px; font-weight: bold; color: #00a32a;">✓</div>
                    <div><?php _e('WP Fort Active', 'wp-fort'); ?></div>
                    <div style="font-size: 12px; color: #646970;"><?php _e('Protected', 'wp-fort'); ?></div>
                </div>
            </div>
        </div>
    </div>
</div>