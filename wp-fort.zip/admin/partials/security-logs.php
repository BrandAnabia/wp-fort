<?php
/**
 * WP Fort Security Logs Interface
 * 
 * @package WP_Fort
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap wp-fort-admin">
    <div class="wp-fort-header">
        <h1><?php _e('Security Logs', 'wp-fort'); ?></h1>
        <p><?php _e('Monitor and analyze security events on your WordPress website.', 'wp-fort'); ?></p>
    </div>

    <form method="post" action="options.php" class="wp-fort-settings-form">
        <?php settings_fields('wp_fort_settings'); ?>
        
        <div class="wp-fort-form-section">
            <h3><?php _e('Logging Settings', 'wp-fort'); ?></h3>
            
            <div class="wp-fort-form-row">
                <label>
                    <input type="checkbox" name="wp_fort_settings[logging_enabled]" value="1" 
                        <?php checked($options['logging_enabled'], 1); ?> 
                        class="wp-fort-toggle">
                    <?php _e('Enable Security Logging', 'wp-fort'); ?>
                </label>
                <p class="wp-fort-form-help">
                    <?php _e('Record security events, login attempts, and suspicious activities.', 'wp-fort'); ?>
                </p>
            </div>

            <div class="wp-fort-form-row">
                <label for="log_retention_days"><?php _e('Log Retention Period (days)', 'wp-fort'); ?></label>
                <input type="number" id="log_retention_days" name="wp_fort_settings[log_retention_days]" 
                    value="<?php echo esc_attr($options['log_retention_days']); ?>" 
                    min="1" max="365" class="small-text">
                <p class="wp-fort-form-help">
                    <?php _e('How long to keep security logs before automatic cleanup.', 'wp-fort'); ?>
                </p>
            </div>
        </div>

        <div class="wp-fort-form-row">
            <?php submit_button(__('Save Settings', 'wp-fort'), 'primary', 'submit'); ?>
        </div>
    </form>

    <div class="wp-fort-form-section">
        <h3><?php _e('Security Logs Management', 'wp-fort'); ?></h3>
        
        <div style="display: flex; gap: 10px; margin-bottom: 20px; flex-wrap: wrap;">
            <button class="wp-fort-btn wp-fort-refresh-logs">
                <?php _e('Refresh Logs', 'wp-fort'); ?>
            </button>
            <button class="wp-fort-btn wp-fort-btn-secondary wp-fort-export-logs">
                <?php _e('Export Logs', 'wp-fort'); ?>
            </button>
            <button class="wp-fort-btn wp-fort-btn-danger wp-fort-clear-logs">
                <?php _e('Clear All Logs', 'wp-fort'); ?>
            </button>
        </div>

        <div class="wp-fort-logs-container">
            <table class="wp-fort-logs-table">
                <thead>
                    <tr>
                        <th><?php _e('Timestamp', 'wp-fort'); ?></th>
                        <th><?php _e('Event Type', 'wp-fort'); ?></th>
                        <th><?php _e('IP Address', 'wp-fort'); ?></th>
                        <th><?php _e('Username', 'wp-fort'); ?></th>
                        <th><?php _e('Country', 'wp-fort'); ?></th>
                        <th><?php _e('Region', 'wp-fort'); ?></th>
                        <th><?php _e('City', 'wp-fort'); ?></th>
                        <th><?php _e('Severity', 'wp-fort'); ?></th>
                        <th><?php _e('Details', 'wp-fort'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Logs will be loaded via AJAX -->
                    <tr>
                        <td colspan="9" style="text-align: center; padding: 40px;">
                            <div class="wp-fort-spinner" style="margin: 0 auto 20px auto;"></div>
                            <?php _e('Loading security logs...', 'wp-fort'); ?>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <div class="wp-fort-logs-pagination" style="margin-top: 20px; text-align: center;">
            <!-- Pagination will be loaded via AJAX -->
        </div>
    </div>

    <div class="wp-fort-form-section">
        <h3><?php _e('Log Event Types', 'wp-fort'); ?></h3>
        
        <table style="width: 100%; border-collapse: collapse;">
            <thead>
                <tr style="background: #f6f7f7;">
                    <th style="padding: 10px; text-align: left; border: 1px solid #dcdcde;"><?php _e('Event Type', 'wp-fort'); ?></th>
                    <th style="padding: 10px; text-align: left; border: 1px solid #dcdcde;"><?php _e('Description', 'wp-fort'); ?></th>
                    <th style="padding: 10px; text-align: left; border: 1px solid #dcdcde;"><?php _e('Severity', 'wp-fort'); ?></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td style="padding: 10px; border: 1px solid #dcdcde;"><code>login_success</code></td>
                    <td style="padding: 10px; border: 1px solid #dcdcde;"><?php _e('Successful admin login', 'wp-fort'); ?></td>
                    <td style="padding: 10px; border: 1px solid #dcdcde;"><span class="wp-fort-severity low"><?php _e('Low', 'wp-fort'); ?></span></td>
                </tr>
                <tr>
                    <td style="padding: 10px; border: 1px solid #dcdcde;"><code>login_failed</code></td>
                    <td style="padding: 10px; border: 1px solid #dcdcde;"><?php _e('Failed login attempt', 'wp-fort'); ?></td>
                    <td style="padding: 10px; border: 1px solid #dcdcde;"><span class="wp-fort-severity medium"><?php _e('Medium', 'wp-fort'); ?></span></td>
                </tr>
                <tr>
                    <td style="padding: 10px; border: 1px solid #dcdcde;"><code>ip_blocked</code></td>
                    <td style="padding: 10px; border: 1px solid #dcdcde;"><?php _e('IP address blocked by firewall', 'wp-fort'); ?></td>
                    <td style="padding: 10px; border: 1px solid #dcdcde;"><span class="wp-fort-severity high"><?php _e('High', 'wp-fort'); ?></span></td>
                </tr>
                <tr>
                    <td style="padding: 10px; border: 1px solid #dcdcde;"><code>brute_force_detected</code></td>
                    <td style="padding: 10px; border: 1px solid #dcdcde;"><?php _e('Brute force attack detected', 'wp-fort'); ?></td>
                    <td style="padding: 10px; border: 1px solid #dcdcde;"><span class="wp-fort-severity critical"><?php _e('Critical', 'wp-fort'); ?></span></td>
                </tr>
                <tr>
                    <td style="padding: 10px; border: 1px solid #dcdcde;"><code>suspicious_request</code></td>
                    <td style="padding: 10px; border: 1px solid #dcdcde;"><?php _e('Suspicious HTTP request detected', 'wp-fort'); ?></td>
                    <td style="padding: 10px; border: 1px solid #dcdcde;"><span class="wp-fort-severity high"><?php _e('High', 'wp-fort'); ?></span></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>