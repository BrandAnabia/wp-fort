<?php
/**
 * WP Fort General Settings
 * 
 * @package WP_Fort
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap wp-fort-admin">
    <div class="wp-fort-header">
        <h1><?php _e('General Settings', 'wp-fort'); ?></h1>
        <p><?php _e('Configure general security settings and WordPress hardening options.', 'wp-fort'); ?></p>
    </div>

    <form method="post" action="options.php" class="wp-fort-settings-form wp-fort-auto-save">
        <?php settings_fields('wp_fort_settings'); ?>
        
        <div class="wp-fort-form-section">
            <h3><?php _e('WordPress Hardening', 'wp-fort'); ?></h3>
            
            <div class="wp-fort-form-row">
                <label>
                    <input type="checkbox" name="wp_fort_settings[disable_xmlrpc]" value="1" 
                        <?php checked($options['disable_xmlrpc'], 1); ?> 
                        class="wp-fort-toggle">
                    <?php _e('Disable XML-RPC', 'wp-fort'); ?>
                </label>
                <p class="wp-fort-form-help">
                    <?php _e('XML-RPC can be exploited for brute force attacks. Disable if not needed.', 'wp-fort'); ?>
                </p>
            </div>

            <div class="wp-fort-form-row">
                <label>
                    <input type="checkbox" name="wp_fort_settings[hide_wp_version]" value="1" 
                        <?php checked($options['hide_wp_version'], 1); ?>>
                    <?php _e('Hide WordPress Version', 'wp-fort'); ?>
                </label>
                <p class="wp-fort-form-help">
                    <?php _e('Remove WordPress version number from source code and RSS feeds.', 'wp-fort'); ?>
                </p>
            </div>

            <div class="wp-fort-form-row">
                <label>
                    <input type="checkbox" name="wp_fort_settings[disable_file_edit]" value="1" 
                        <?php checked($options['disable_file_edit'], 1); ?>>
                    <?php _e('Disable File Editor', 'wp-fort'); ?>
                </label>
                <p class="wp-fort-form-help">
                    <?php _e('Prevent users from editing theme and plugin files from the WordPress admin.', 'wp-fort'); ?>
                </p>
            </div>
        </div>

        <div class="wp-fort-form-section">
            <h3><?php _e('Security Headers', 'wp-fort'); ?></h3>
            
            <div class="wp-fort-form-row">
                <label>
                    <input type="checkbox" name="wp_fort_settings[security_headers]" value="1" 
                        <?php checked($options['security_headers'] ?? true, 1); ?> 
                        class="wp-fort-toggle">
                    <?php _e('Enable Security Headers', 'wp-fort'); ?>
                </label>
                <p class="wp-fort-form-help">
                    <?php _e('Add security headers to protect against XSS, clickjacking, and other attacks.', 'wp-fort'); ?>
                </p>
            </div>

            <div class="wp-fort-form-row">
                <label><?php _e('Current Security Headers', 'wp-fort'); ?></label>
                <div style="background: #f6f7f7; padding: 15px; border-radius: 4px; font-family: monospace; font-size: 12px;">
                    X-Content-Type-Options: nosniff<br>
                    X-Frame-Options: SAMEORIGIN<br>
                    X-XSS-Protection: 1; mode=block<br>
                    Referrer-Policy: strict-origin-when-cross-origin<br>
                    <?php if (is_ssl()): ?>
                    Strict-Transport-Security: max-age=31536000; includeSubDomains
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="wp-fort-form-section">
            <h3><?php _e('Database Security', 'wp-fort'); ?></h3>
            
            <div class="wp-fort-form-row">
                <label>
                    <input type="checkbox" name="wp_fort_settings[db_prefix_change]" value="1" 
                        <?php checked($options['db_prefix_change'] ?? false, 1); ?>>
                    <?php _e('Change Database Prefix', 'wp-fort'); ?>
                </label>
                <p class="wp-fort-form-help">
                    <?php _e('Change WordPress database table prefix from default wp_ to something unique.', 'wp-fort'); ?>
                    <strong style="color: #d63638;">
                        <?php _e('Backup your database before enabling this feature!', 'wp-fort'); ?>
                    </strong>
                </p>
            </div>

            <div class="wp-fort-form-row">
                <label for="custom_db_prefix"><?php _e('Custom Database Prefix', 'wp-fort'); ?></label>
                <input type="text" id="custom_db_prefix" name="wp_fort_settings[custom_db_prefix]" 
                    value="<?php echo esc_attr($options['custom_db_prefix'] ?? 'wp_'); ?>" 
                    class="regular-text" placeholder="wp_">
                <p class="wp-fort-form-help">
                    <?php _e('Use alphanumeric characters and underscores only. Must end with underscore.', 'wp-fort'); ?>
                </p>
            </div>
        </div>

        <div class="wp-fort-form-section">
            <h3><?php _e('Maintenance & Cleanup', 'wp-fort'); ?></h3>
            
            <div class="wp-fort-form-row">
                <label for="auto_cleanup_days"><?php _e('Auto Cleanup Logs (days)', 'wp-fort'); ?></label>
                <input type="number" id="auto_cleanup_days" name="wp_fort_settings[auto_cleanup_days]" 
                    value="<?php echo esc_attr($options['auto_cleanup_days'] ?? 30); ?>" 
                    min="1" max="365" class="small-text">
                <p class="wp-fort-form-help">
                    <?php _e('Automatically delete security logs older than specified days.', 'wp-fort'); ?>
                </p>
            </div>

            <div class="wp-fort-form-row">
                <label>
                    <input type="checkbox" name="wp_fort_settings[enable_debug_log]" value="1" 
                        <?php checked($options['enable_debug_log'] ?? false, 1); ?>>
                    <?php _e('Enable Debug Logging', 'wp-fort'); ?>
                </label>
                <p class="wp-fort-form-help">
                    <?php _e('Log debug information for troubleshooting purposes. Disable in production.', 'wp-fort'); ?>
                </p>
            </div>
        </div>

        <div class="wp-fort-form-row">
            <?php submit_button(__('Save Settings', 'wp-fort'), 'primary', 'submit'); ?>
        </div>
    </form>

    <div class="wp-fort-form-section">
        <h3><?php _e('Plugin Information', 'wp-fort'); ?></h3>
        
        <table style="width: 100%; border-collapse: collapse;">
            <tr>
                <td style="padding: 10px; border: 1px solid #dcdcde; width: 200px; background: #f6f7f7;">
                    <strong><?php _e('Plugin Version', 'wp-fort'); ?></strong>
                </td>
                <td style="padding: 10px; border: 1px solid #dcdcde;">
                    <?php echo esc_html(WP_FORT_VERSION); ?>
                </td>
            </tr>
            <tr>
                <td style="padding: 10px; border: 1px solid #dcdcde; background: #f6f7f7;">
                    <strong><?php _e('WordPress Version', 'wp-fort'); ?></strong>
                </td>
                <td style="padding: 10px; border: 1px solid #dcdcde;">
                    <?php echo esc_html(get_bloginfo('version')); ?>
                </td>
            </tr>
            <tr>
                <td style="padding: 10px; border: 1px solid #dcdcde; background: #f6f7f7;">
                    <strong><?php _e('PHP Version', 'wp-fort'); ?></strong>
                </td>
                <td style="padding: 10px; border: 1px solid #dcdcde;">
                    <?php echo esc_html(phpversion()); ?>
                </td>
            </tr>
            <tr>
                <td style="padding: 10px; border: 1px solid #dcdcde; background: #f6f7f7;">
                    <strong><?php _e('Database Version', 'wp-fort'); ?></strong>
                </td>
                <td style="padding: 10px; border: 1px solid #dcdcde;">
                    <?php global $wpdb; echo esc_html($wpdb->db_version()); ?>
                </td>
            </tr>
            <tr>
                <td style="padding: 10px; border: 1px solid #dcdcde; background: #f6f7f7;">
                    <strong><?php _e('Security Logs Count', 'wp-fort'); ?></strong>
                </td>
                <td style="padding: 10px; border: 1px solid #dcdcde;">
                    <?php
                    global $wpdb;
                    $logs_count = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}wp_fort_security_logs");
                    echo esc_html($logs_count);
                    ?>
                </td>
            </tr>
        </table>
    </div>

    <div class="wp-fort-form-section">
        <h3><?php _e('Quick Actions', 'wp-fort'); ?></h3>
        
        <div style="display: flex; gap: 10px; flex-wrap: wrap;">
            <button class="wp-fort-btn wp-fort-btn-danger" id="reset-settings">
                <?php _e('Reset All Settings', 'wp-fort'); ?>
            </button>
            <button class="wp-fort-btn wp-fort-btn-secondary" id="export-settings">
                <?php _e('Export Settings', 'wp-fort'); ?>
            </button>
            <button class="wp-fort-btn wp-fort-btn-secondary" id="import-settings">
                <?php _e('Import Settings', 'wp-fort'); ?>
            </button>
            <a href="<?php echo admin_url('admin.php?page=wp-fort&tab=debug'); ?>" class="wp-fort-btn wp-fort-btn-secondary">
                <?php _e('Debug Information', 'wp-fort'); ?>
            </a>
        </div>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    $('#reset-settings').on('click', function() {
        if (confirm('Are you sure you want to reset all WP Fort settings? This action cannot be undone.')) {
            // This would typically make an AJAX call to reset settings
            alert('Settings reset functionality would be implemented here.');
        }
    });
    
    $('#export-settings').on('click', function() {
        alert('Settings export functionality would be implemented here.');
    });
    
    $('#import-settings').on('click', function() {
        alert('Settings import functionality would be implemented here.');
    });
});
</script>