<?php
/**
 * WP Fort Login Protection Settings
 * 
 * @package WP_Fort
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

$current_domain = parse_url(home_url(), PHP_URL_HOST);
$available_domains = array($current_domain);
// You can add more domains here if you have multiple domains
?>

<div class="wrap wp-fort-admin">
    <div class="wp-fort-header">
        <h1><?php _e('Login Protection Settings', 'wp-fort'); ?></h1>
        <p><?php _e('Secure your WordPress login with custom URLs and advanced protection.', 'wp-fort'); ?></p>
    </div>

    <form method="post" action="options.php" class="wp-fort-settings-form wp-fort-auto-save">
        <?php settings_fields('wp_fort_settings'); ?>
        
        <div class="wp-fort-form-section">
            <h3><?php _e('Custom Login URL', 'wp-fort'); ?></h3>
            
            <div class="wp-fort-form-row">
                <label>
                    <input type="checkbox" name="wp_fort_settings[login_protection_enabled]" value="1" 
                        <?php checked($options['login_protection_enabled'], 1); ?> 
                        class="wp-fort-toggle">
                    <?php _e('Enable Custom Login URL Protection', 'wp-fort'); ?>
                </label>
                <p class="wp-fort-form-help">
                    <?php _e('Hide the default wp-login.php and use a custom URL for admin access.', 'wp-fort'); ?>
                </p>
            </div>

            <div class="wp-fort-form-row">
                <label for="custom_login_domain"><?php _e('Login Domain', 'wp-fort'); ?></label>
                <select id="custom_login_domain" name="wp_fort_settings[custom_login_domain]" class="regular-text">
                    <?php foreach ($available_domains as $domain): ?>
                        <option value="<?php echo esc_attr($domain); ?>" 
                            <?php selected($options['custom_login_domain'] ?? $current_domain, $domain); ?>>
                            <?php echo esc_html($domain); ?>
                        </option>
                    <?php endforeach; ?>
                    <option value="custom" <?php selected($options['custom_login_domain'] ?? '', 'custom'); ?>>
                        <?php _e('Custom Domain', 'wp-fort'); ?>
                    </option>
                </select>
                <p class="wp-fort-form-help">
                    <?php _e('Select the domain for your custom login URL.', 'wp-fort'); ?>
                </p>
            </div>

            <div class="wp-fort-form-row" id="custom-domain-field" 
                style="<?php echo (($options['custom_login_domain'] ?? '') === 'custom') ? '' : 'display: none;'; ?>">
                <label for="custom_domain_input"><?php _e('Custom Domain', 'wp-fort'); ?></label>
                <input type="text" id="custom_domain_input" name="wp_fort_settings[custom_domain]" 
                    value="<?php echo esc_attr($options['custom_domain'] ?? ''); ?>" 
                    class="regular-text" placeholder="login.yourdomain.com">
                <p class="wp-fort-form-help">
                    <?php _e('Enter a custom domain for your login URL (e.g., login.yourdomain.com).', 'wp-fort'); ?>
                </p>
            </div>

            <div class="wp-fort-form-row">
                <label for="custom_login_slug"><?php _e('Custom Login Path', 'wp-fort'); ?></label>
                <input type="text" id="custom_login_slug" name="wp_fort_settings[custom_login_slug]" 
                    value="<?php echo esc_attr($options['custom_login_slug']); ?>" 
                    class="regular-text wp-fort-custom-login-url"
                    placeholder="secure-admin">
                <p class="wp-fort-form-help">
                    <?php _e('Choose a unique path for your login page. Example:', 'wp-fort'); ?>
                    <code><?php echo esc_url(home_url('secure-admin')); ?></code>
                </p>
            </div>

            <div class="wp-fort-form-row">
                <label>
                    <input type="checkbox" name="wp_fort_settings[block_wp_login]" value="1" 
                        <?php checked($options['block_wp_login'], 1); ?>>
                    <?php _e('Block Access to wp-login.php', 'wp-fort'); ?>
                </label>
                <p class="wp-fort-form-help">
                    <?php _e('Completely block access to the default WordPress login page.', 'wp-fort'); ?>
                </p>
            </div>

            <?php if ($options['login_protection_enabled'] && !empty($options['custom_login_slug'])): 
                $login_domain = $options['custom_login_domain'] ?? $current_domain;
                $login_url = ($login_domain === 'custom' && !empty($options['custom_domain'])) 
                    ? 'https://' . $options['custom_domain'] . '/' . $options['custom_login_slug']
                    : home_url($options['custom_login_slug']);
            ?>
            <div class="wp-fort-form-row" style="background: #edfaef; padding: 15px; border-radius: 4px; border-left: 4px solid #00a32a;">
                <strong><?php _e('Your Custom Login URL:', 'wp-fort'); ?></strong><br>
                <code style="font-size: 16px; margin-top: 8px; display: inline-block;">
                    <?php echo esc_url($login_url); ?>
                </code>
                <div style="margin-top: 10px;">
                    <button type="button" class="wp-fort-btn wp-fort-btn-secondary" onclick="window.open('<?php echo esc_url($login_url); ?>', '_blank')">
                        <?php _e('Test Login URL', 'wp-fort'); ?>
                    </button>
                    <button type="button" class="wp-fort-btn wp-fort-btn-secondary" onclick="copyToClipboard('<?php echo esc_url($login_url); ?>')">
                        <?php _e('Copy URL', 'wp-fort'); ?>
                    </button>
                </div>
                <p style="margin: 8px 0 0 0; color: #666;">
                    <?php _e('Bookmark this URL for future access. Share with authorized users only.', 'wp-fort'); ?>
                </p>
            </div>
            <?php endif; ?>
        </div>

        <div class="wp-fort-form-section">
            <h3><?php _e('IP-Based Access Control', 'wp-fort'); ?></h3>
            
            <div class="wp-fort-form-row">
                <label>
                    <input type="checkbox" name="wp_fort_settings[ip_restriction_enabled]" value="1" 
                        <?php checked($options['ip_restriction_enabled'], 1); ?> 
                        class="wp-fort-toggle">
                    <?php _e('Restrict Admin Access to Specific IPs', 'wp-fort'); ?>
                </label>
                <p class="wp-fort-form-help">
                    <?php _e('Only allow access to admin area and custom login from specific IP addresses.', 'wp-fort'); ?>
                </p>
            </div>

            <div class="wp-fort-form-row">
                <div style="background: #f0f6fc; padding: 15px; border-radius: 4px; border-left: 4px solid #2271b1;">
                    <strong><?php _e('Your Current IP Address:', 'wp-fort'); ?></strong><br>
                    <code style="font-size: 16px; margin-top: 8px; display: inline-block;">
                        <?php echo esc_html(WP_Fort_Core::get_client_ip()); ?>
                    </code>
                    <p style="margin: 8px 0 0 0; color: #666;">
                        <?php _e('Make sure to add this IP to the whitelist in IP Restrictions tab.', 'wp-fort'); ?>
                    </p>
                </div>
            </div>
        </div>

        <div class="wp-fort-form-section">
            <h3><?php _e('Brute Force Protection', 'wp-fort'); ?></h3>
            
            <div class="wp-fort-form-row">
                <label>
                    <input type="checkbox" name="wp_fort_settings[brute_force_protection]" value="1" 
                        <?php checked($options['brute_force_protection'], 1); ?> 
                        class="wp-fort-toggle">
                    <?php _e('Enable Brute Force Protection', 'wp-fort'); ?>
                </label>
                <p class="wp-fort-form-help">
                    <?php _e('Automatically block IP addresses after multiple failed login attempts.', 'wp-fort'); ?>
                </p>
            </div>

            <div class="wp-fort-form-row">
                <label for="max_login_attempts"><?php _e('Maximum Login Attempts', 'wp-fort'); ?></label>
                <input type="number" id="max_login_attempts" name="wp_fort_settings[max_login_attempts]" 
                    value="<?php echo esc_attr($options['max_login_attempts']); ?>" 
                    min="1" max="20" class="small-text">
                <p class="wp-fort-form-help">
                    <?php _e('Number of failed login attempts before temporary lockout.', 'wp-fort'); ?>
                </p>
            </div>

            <div class="wp-fort-form-row">
                <label for="lockout_duration"><?php _e('Lockout Duration (minutes)', 'wp-fort'); ?></label>
                <input type="number" id="lockout_duration" name="wp_fort_settings[lockout_duration]" 
                    value="<?php echo esc_attr($options['lockout_duration']); ?>" 
                    min="1" max="1440" class="small-text">
                <p class="wp-fort-form-help">
                    <?php _e('How long to block IP addresses after reaching maximum attempts.', 'wp-fort'); ?>
                </p>
            </div>
        </div>

        <div class="wp-fort-form-section">
            <h3><?php _e('Additional Login Security', 'wp-fort'); ?></h3>
            
            <div class="wp-fort-form-row">
                <label>
                    <input type="checkbox" name="wp_fort_settings[log_failed_logins]" value="1" 
                        <?php checked($options['log_failed_logins'], 1); ?>>
                    <?php _e('Log Failed Login Attempts', 'wp-fort'); ?>
                </label>
                <p class="wp-fort-form-help">
                    <?php _e('Record all failed login attempts in security logs.', 'wp-fort'); ?>
                </p>
            </div>

            <div class="wp-fort-form-row">
                <label>
                    <input type="checkbox" name="wp_fort_settings[log_successful_logins]" value="1" 
                        <?php checked($options['log_successful_logins'], 1); ?>>
                    <?php _e('Log Successful Logins', 'wp-fort'); ?>
                </label>
                <p class="wp-fort-form-help">
                    <?php _e('Record successful admin logins for audit purposes.', 'wp-fort'); ?>
                </p>
            </div>
        </div>

        <div class="wp-fort-form-row">
            <?php submit_button(__('Save Settings', 'wp-fort'), 'primary', 'submit'); ?>
        </div>
    </form>

    <div class="wp-fort-form-section">
        <h3><?php _e('Security Tips', 'wp-fort'); ?></h3>
        <ul style="list-style: disc; padding-left: 20px;">
            <li><?php _e('Always use a strong, unique custom login path', 'wp-fort'); ?></li>
            <li><?php _e('Enable IP restrictions to limit access to trusted networks', 'wp-fort'); ?></li>
            <li><?php _e('Enable brute force protection to prevent automated attacks', 'wp-fort'); ?></li>
            <li><?php _e('Regularly monitor your security logs for suspicious activity', 'wp-fort'); ?></li>
            <li><?php _e('Consider using a completely different domain for admin access', 'wp-fort'); ?></li>
        </ul>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    // Show/hide custom domain field
    $('#custom_login_domain').on('change', function() {
        if ($(this).val() === 'custom') {
            $('#custom-domain-field').show();
        } else {
            $('#custom-domain-field').hide();
        }
    });

    // Copy to clipboard function
    window.copyToClipboard = function(text) {
        const textarea = document.createElement('textarea');
        textarea.value = text;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        
        alert('Login URL copied to clipboard!');
    };
});
</script>