<?php
/**
 * WP Fort Cloudflare Integration
 * 
 * @package WP_Fort
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap wp-fort-admin">
    <div class="wp-fort-header">
        <h1><?php _e('Cloudflare Integration', 'wp-fort'); ?></h1>
        <p><?php _e('Enhance your website security with Cloudflare firewall and DDoS protection.', 'wp-fort'); ?></p>
    </div>

    <form method="post" action="options.php" class="wp-fort-settings-form">
        <?php settings_fields('wp_fort_settings'); ?>
        
        <div class="wp-fort-form-section">
            <h3><?php _e('Cloudflare API Configuration', 'wp-fort'); ?></h3>
            
            <div class="wp-fort-form-row">
                <label>
                    <input type="checkbox" name="wp_fort_settings[cloudflare_enabled]" value="1" 
                        <?php checked($options['cloudflare_enabled'], 1); ?> 
                        class="wp-fort-toggle">
                    <?php _e('Enable Cloudflare Integration', 'wp-fort'); ?>
                </label>
                <p class="wp-fort-form-help">
                    <?php _e('Connect to Cloudflare API for enhanced security features.', 'wp-fort'); ?>
                </p>
            </div>

            <div class="wp-fort-form-row">
                <label for="cloudflare_email"><?php _e('Cloudflare Email', 'wp-fort'); ?></label>
                <input type="email" id="cloudflare_email" name="wp_fort_settings[cloudflare_email]" 
                    value="<?php echo esc_attr($options['cloudflare_email']); ?>" 
                    class="regular-text" placeholder="your-email@example.com">
                <p class="wp-fort-form-help">
                    <?php _e('The email address associated with your Cloudflare account.', 'wp-fort'); ?>
                </p>
            </div>

            <div class="wp-fort-form-row">
                <label for="cloudflare_api_key"><?php _e('Cloudflare API Key', 'wp-fort'); ?></label>
                <input type="password" id="cloudflare_api_key" name="wp_fort_settings[cloudflare_api_key]" 
                    value="<?php echo esc_attr($options['cloudflare_api_key']); ?>" 
                    class="regular-text" placeholder="Your Cloudflare API Key">
                <p class="wp-fort-form-help">
                    <?php 
                    printf(
                        __('Get your API key from %s', 'wp-fort'),
                        '<a href="https://dash.cloudflare.com/profile/api-tokens" target="_blank">https://dash.cloudflare.com/profile/api-tokens</a>'
                    ); 
                    ?>
                </p>
            </div>

            <div class="wp-fort-form-row">
                <label for="cloudflare_zone_id"><?php _e('Zone ID', 'wp-fort'); ?></label>
                <input type="text" id="cloudflare_zone_id" name="wp_fort_settings[cloudflare_zone_id]" 
                    value="<?php echo esc_attr($options['cloudflare_zone_id']); ?>" 
                    class="regular-text" placeholder="Your Cloudflare Zone ID">
                <p class="wp-fort-form-help">
                    <?php _e('The Zone ID for your domain in Cloudflare.', 'wp-fort'); ?>
                </p>
            </div>

            <?php if (!empty($options['cloudflare_api_key']) && !empty($options['cloudflare_zone_id'])): ?>
            <div class="wp-fort-form-row">
                <button type="button" class="wp-fort-btn wp-fort-btn-secondary" id="test-cloudflare-connection">
                    <?php _e('Test Cloudflare Connection', 'wp-fort'); ?>
                </button>
                <span id="cloudflare-test-result" style="margin-left: 10px;"></span>
            </div>
            <?php endif; ?>
        </div>

        <div class="wp-fort-form-section">
            <h3><?php _e('Cloudflare Security Features', 'wp-fort'); ?></h3>
            
            <div class="wp-fort-form-row">
                <label>
                    <input type="checkbox" name="wp_fort_settings[cloudflare_firewall_rules]" value="1" 
                        <?php checked($options['cloudflare_firewall_rules'] ?? false, 1); ?>>
                    <?php _e('Automatically Create Firewall Rules', 'wp-fort'); ?>
                </label>
                <p class="wp-fort-form-help">
                    <?php _e('Automatically create Cloudflare firewall rules for blocked IPs and suspicious activities.', 'wp-fort'); ?>
                </p>
            </div>

            <div class="wp-fort-form-row">
                <label>
                    <input type="checkbox" name="wp_fort_settings[cloudflare_threat_analytics]" value="1" 
                        <?php checked($options['cloudflare_threat_analytics'] ?? false, 1); ?>>
                    <?php _e('Enable Threat Analytics', 'wp-fort'); ?>
                </label>
                <p class="wp-fort-form-help">
                    <?php _e('Sync security events with Cloudflare threat analytics for better insights.', 'wp-fort'); ?>
                </p>
            </div>

            <div class="wp-fort-form-row">
                <label>
                    <input type="checkbox" name="wp_fort_settings[cloudflare_ddos_protection]" value="1" 
                        <?php checked($options['cloudflare_ddos_protection'] ?? false, 1); ?>>
                    <?php _e('Enhanced DDoS Protection', 'wp-fort'); ?>
                </label>
                <p class="wp-fort-form-help">
                    <?php _e('Leverage Cloudflare\'s DDoS protection for your WordPress site.', 'wp-fort'); ?>
                </p>
            </div>
        </div>

        <div class="wp-fort-form-row">
            <?php submit_button(__('Save Settings', 'wp-fort'), 'primary', 'submit'); ?>
        </div>
    </form>

    <div class="wp-fort-form-section">
        <h3><?php _e('Cloudflare Benefits', 'wp-fort'); ?></h3>
        
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px;">
            <div style="padding: 20px; background: #f0f6fc; border-radius: 6px; border-left: 4px solid #2271b1;">
                <h4 style="margin-top: 0;"><?php _e('DDoS Protection', 'wp-fort'); ?></h4>
                <p style="margin: 0;"><?php _e('Protect your site from distributed denial-of-service attacks with Cloudflare\'s global network.', 'wp-fort'); ?></p>
            </div>
            
            <div style="padding: 20px; background: #f0f6fc; border-radius: 6px; border-left: 4px solid #2271b1;">
                <h4 style="margin-top: 0;"><?php _e('Web Application Firewall', 'wp-fort'); ?></h4>
                <p style="margin: 0;"><?php _e('Advanced WAF rules to block SQL injection, XSS, and other common attacks.', 'wp-fort'); ?></p>
            </div>
            
            <div style="padding: 20px; background: #f0f6fc; border-radius: 6px; border-left: 4px solid #2271b1;">
                <h4 style="margin-top: 0;"><?php _e('Threat Intelligence', 'wp-fort'); ?></h4>
                <p style="margin: 0;"><?php _e('Leverage Cloudflare\'s global threat intelligence to block malicious traffic.', 'wp-fort'); ?></p>
            </div>
            
            <div style="padding: 20px; background: #f0f6fc; border-radius: 6px; border-left: 4px solid #2271b1;">
                <h4 style="margin-top: 0;"><?php _e('Performance Boost', 'wp-fort'); ?></h4>
                <p style="margin: 0;"><?php _e('Improved site performance through Cloudflare\'s CDN and optimization features.', 'wp-fort'); ?></p>
            </div>
        </div>
    </div>

    <div class="wp-fort-form-section">
        <h3><?php _e('Setup Instructions', 'wp-fort'); ?></h3>
        
        <ol style="padding-left: 20px;">
            <li><?php _e('Sign up for a Cloudflare account at', 'wp-fort'); ?> <a href="https://cloudflare.com" target="_blank">cloudflare.com</a></li>
            <li><?php _e('Add your website to Cloudflare and update your domain\'s nameservers', 'wp-fort'); ?></li>
            <li><?php _e('Go to your Cloudflare dashboard and navigate to My Profile > API Tokens', 'wp-fort'); ?></li>
            <li><?php _e('Create an API token with appropriate permissions (Zone:Read, Zone:Write)', 'wp-fort'); ?></li>
            <li><?php _e('Find your Zone ID in the Cloudflare dashboard under your domain overview', 'wp-fort'); ?></li>
            <li><?php _e('Enter your Cloudflare email, API key, and Zone ID in the form above', 'wp-fort'); ?></li>
            <li><?php _e('Test the connection and enable desired security features', 'wp-fort'); ?></li>
        </ol>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    $('#test-cloudflare-connection').on('click', function() {
        const $button = $(this);
        const $result = $('#cloudflare-test-result');
        
        $button.addClass('wp-fort-loading').prop('disabled', true);
        $result.html('<span class="wp-fort-spinner" style="margin-right: 5px;"></span> Testing...');
        
        // This would typically make an AJAX call to test the connection
        setTimeout(function() {
            $button.removeClass('wp-fort-loading').prop('disabled', false);
            $result.html('<span style="color: #00a32a;">✓ Connection successful!</span>');
        }, 2000);
    });
});
</script>